<div class="headerinner">
    <div class="headerinnertop">
      <div class="container">
        <div class="headtoprow">
          <div class="logocontainer">            
            <div class="logoinner">
              <a href="<?php echo e(url('/')); ?>"><img src="<?php echo e(url('/')); ?>/<?php echo e($data['settings']->store_logo); ?>" alt="" /></a>
            </div>
          </div>
          <div class="rightuserbox">
            <?php
            $user_exist=session()->get('userexist');
            ?>
            <?php if($user_exist): ?>
             <div class="afterlogin-user">
              <a id="UserNav" class="utext" href="javascript:void(0);">Hello 
                <?php
                $name = explode(" ", $data['userDetails']->name)
                ?>
                <?php echo e($name[0]); ?></a>
              <div id="UserNavBody" class="afterloginnav">
                <ul>
                  <li><a href="<?php echo e(url('/dashboard')); ?>"><i class="icon icon-dashboard"></i>Dashboard</a></li>
                  <li><a href="<?php echo e(url('/update-account')); ?>"><i class="icon icon-user-pencil"></i>Update Account</a></li>
                  <li><a href="<?php echo e(url('/post-add')); ?>"><i class="icon icon-speaker"></i>Post a new Ad</a></li>
                  <li><a href="<?php echo e(('logout')); ?>"><i class="icon icon-power-off"></i>Logout</a></li>
                </ul>
              </div>
            </div>            
            <?php else: ?>
            <a href="<?php echo e(url(app()->getLocale().'/login')); ?>" class="loginbtn"><i class="fa fa-user"></i><span><?php echo app('translator')->getFromJson('home.login_txt'); ?></span></a>
            <a href="javascript:void(0);" class="sellbtn"><i class="fa fa-camera"></i><span><?php echo app('translator')->getFromJson('home.sell_txt'); ?></span></a>
            <?php endif; ?>       
            <div class="lanbox dropdown">
              <a id="dLabel" data-target="#" href="#" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><span class="lanspan">
                         
                <?php if('en' == $data['curr_lang']): ?>
                <span class="flag-icon flag-icon-gb"></span>
                <?php else: ?>
                <span class="flag-icon flag-icon-us"></span>
                <?php endif; ?>
             
              </span></a>
             <ul class="dropdown-menu" aria-labelledby="dLabel">
                <li><a class="dropdown-item" href="<?php echo e(route('locale.switch', 'en')); ?>"><span class="flag-icon flag-icon-gb"> </span></a></li>

                <li><a class="dropdown-item" href="<?php echo e(route('locale.switch', 'ge')); ?>"><span class="flag-icon flag-icon-us"> </span></a></li>
               <!--  <li><a class="dropdown-item" href="#au"><span class="flag-icon flag-icon-au"> </span></a></li>  -->
              </ul>
             
            </div>       

            <div class="socialtop">
               <?php $__currentLoopData = $data['socialMedia']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <a href="<?php echo e($category->link); ?>" target="_blank"><i class="<?php echo e($category->icon); ?>"></i></a>                
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>       
            </div>
            <a href="javascript:void(0);" class="NavBar"><i class="icon icon-segment"></i></a>
          </div>
        </div>
      </div>
    </div>
  </div>