<?php $slug = end(explode("/", $_SERVER['REQUEST_URI']));
?>
<ul class="sf-menu">
  <li <?php if($slug =="dashboard"): ?> class="active" <?php endif; ?>><a href="<?php echo e(url('/dashboard')); ?>"><i class="icon icon-dashboard"></i><?php echo app('translator')->getFromJson('dashboard.dashboard_txt'); ?></a></li>
  <li <?php if($slug =="update-account"): ?> class="active" <?php endif; ?>><a href="<?php echo e(url('/update-account')); ?>"><i class="icon icon-user-pencil"></i>Update Account</a></li>
  <li <?php if($slug =="purchase-packages"): ?> class="active" <?php endif; ?>><a href="<?php echo e(url('/purchase-packages')); ?>" ><i class="icon icon-shopping-basket"></i>Purchase Package</a></li>
  <li <?php if($slug =="wallet"): ?> class="active" <?php endif; ?>><a href="<?php echo e(url('/wallet')); ?>"><i class="icon icon-wallet"></i>Wallet</a></li>
  <li>
    <a href="javascript:void(0);"><i class="icon icon-comment"></i>Send Message</a>
    <ul>
      <li><a href="javascript:void(0);">Site Administrator</a></li>
      <li><a href="javascript:void(0);">Other Members</a></li>
    </ul>
  </li>
  <li <?php if($slug =="post-add"): ?> class="active" <?php endif; ?>><a href="<?php echo e(url('/post-add')); ?>"><i class="icon icon-speaker"></i>Post a new Ad</a></li>
  <li><a href="javascript:void(0);"><i class="icon icon-digital-marketing"></i>View and Manage Ads</a></li>
  <li <?php if($slug =="view-inquiries"): ?> class="active" <?php endif; ?>><a href="<?php echo e(url('/view-inquiries')); ?>"><i class="icon icon-search"></i>View Inquiries</a></li>
  <li><a href="<?php echo e(('logout')); ?>"><i class="icon icon-power-off"></i>Logout</a></li>
</ul>