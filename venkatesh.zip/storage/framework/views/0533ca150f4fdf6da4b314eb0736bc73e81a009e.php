<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <?php echo $__env->make('layout.head', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>  
</head>
<body>

<header class="headercontainer">
  <?php echo $__env->make('layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>  

  <?php echo $__env->make('layout.nav', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>  
</header>

  <?php echo $__env->yieldContent('content'); ?>


<footer class="footercontainer">
  <div class="container">
    <div class="row">
      <div class="col-xl-3 col-md-6 col-sm-12 col-12">
        <div class="visitboxouter">
          <div class="visitboxcolumn">
            <h3>Number of Users</h3>
            <h5>2490+</h5>
          </div>
          <div class="visitboxcolumn">
            <h3>Number of Visitors</h3>
            <h5>7032+</h5>
          </div>
        </div>
      </div>
      <div class="col-xl-6 col-md-6 col-sm-12 col-12">
        <div class="feedbackform">
          <h3>Please Give your Feedback</h3>
          <div class="row">
            <div class="col-xl-6 col-md-6 col-sm-12 col-12">
              <div class="form-group">
                <input type="text" class="form-control" placeholder="Name" name="">
              </div>
            </div>
            <div class="col-xl-6 col-md-6 col-sm-12 col-12">
              <div class="form-group">
                <input type="text" class="form-control" placeholder="Email Id" name="">
              </div>
            </div>
            <div class="col-xl-12 col-md-12 col-sm-12 col-12">
              <div class="form-group">
                <input type="text" class="form-control" placeholder="Type your Message" name="">
              </div>
            </div>
            <div class="col-xl-12 col-md-12 col-sm-12 col-12">
              <a href="javascript:void(0);" class="feedbtn"><span>Submit</span><i class="icon icon-arrow-thin-right"></i></a>
            </div>
          </div>
        </div>
      </div>
      <div class="col-xl-3 col-md-12 col-sm-12 col-12">
        <div class="emailbox">
          <div class="emailboxinner">
            <div class="emailboxicon">
              <i class="fa fa-envelope"></i>
            </div>
            <div class="emailboxcontent">
              <h3>Email Us At</h3>
              <p><a href="mailto:info@g9x.gmail.com">info@g9x.gmail.com</a></p>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="row">
      <div class="col-12">
        <div class="footernav">
          <ul>
            <li><a href="javascript:void(0);">About Us</a></li>
            <li><a href="javascript:void(0);">Customer Service</a></li>
            <li><a href="javascript:void(0);">Contact Us</a></li>
            <li><a href="javascript:void(0);">Terms and Conditions</a></li>
            <li><a href="javascript:void(0);"> Privacy Policy</a></li>
          </ul>
          <div class="copyright">&copy; 2020, <a href="index.html">GX9</a> - All rights reserved</div>
        </div>
      </div>
    </div>
  </div>
</footer>

<a id="SlideUp" class="scrollup" href="javascript:void(0);"><i class="icon icon-arrow-thin-up"></i></a>

<script src="js/jquery-3.2.1.min.js"></script>
<script src="js/popper.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script type="text/javascript" src="js/owl.carousel.min.js"></script>
<script src="js/wow.min.js"></script>
<script type="text/javascript" src="js/custom.js"></script>
<script>
  wow = new WOW(
 {
   animateClass: 'animated',
   offset:       100,
   callback:     function(box) {
     console.log("WOW: animating <" + box.tagName.toLowerCase() + ">")
   }
 }
 );
  wow.init();
</script>
<script type="text/javascript">
  $(document).ready(function () {
    $(window).scroll(function () {
      if ($(this).scrollTop() > 100) {
        $('#SlideUp').fadeIn();
      } else {
        $('#SlideUp').fadeOut();
      }
    });
    $('#SlideUp').click(function () {
      $("html, body").animate({
        scrollTop: 0
      }, 600);
      return false;
    });
  });
</script>
</body>
</html>