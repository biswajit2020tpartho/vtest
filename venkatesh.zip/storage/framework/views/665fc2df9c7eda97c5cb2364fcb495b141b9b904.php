    

    <?php $__env->startSection('content'); ?>

    <div class="dashboard">
	  <div class="dashboardcontainer">
	    <div class="afterloginnavigation">
	      <div class="usercolumn">
	        <div class="userimg">
	        <?php if($userDetails->photo): ?>
	          <img src="<?php echo e(url('/')); ?>/<?php echo e($userDetails->photo); ?>" alt="User Image">
	        <?php else: ?>
	          <img src="<?php echo e(url('/')); ?>/images/user-noimage.jpg" alt="User Image">
	        <?php endif; ?>
	        </div>
	        <h3><?php echo e($userDetails->name); ?></h3>
	        <!-- <p>Visual artist</p> -->
	      </div>
	      <div class="usernavlist">
	         <?php echo $__env->make('layout.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?> 
	      </div>
	    </div>
	    <div class="layoutcontainer">
	      <div class="layoutcontent">
	        <div class="layoutcontentinner">
	          <div class="afterrightbox">
	          <a class="profilebtn" href="javascript:void(0);"><i class="icon icon-user"></i><span>Profile Nav</span></a>
	          <h3>Dashboard / Post a new add</h3>
	          <div class="row">
	          	 <?php if(Session::has('error_message')): ?>
              <div class="alert <?php echo e(Session::get('alert-class', 'alert-danger alert-dismissible')); ?>"><?php echo e(Session::get('error_message')); ?><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button></div>
              <?php endif; ?> 
              <?php if(Session::has('success_message')): ?>
              <div class="alert <?php echo e(Session::get('alert-class', 'alert-success alert-dismissible')); ?>"><?php echo e(Session::get('success_message')); ?><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button></div>
              <?php endif; ?> 
               <?php if($errors->any()): ?>
              <div class="alert alert-danger">
                <ul>
                  <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
              </div>
              <?php endif; ?>
	          	<form name="" method="post" action="<?php echo e(url('en/user-update')); ?>">
	          	<?php echo csrf_field(); ?>
	          	<input type="hidden" name="user_id" value="<?php echo e($userDetails->id); ?>">
	            <div class="col-xl-9 col-md-11 col-sm-12 col-12">
	              <div class="row ml-n2 mr-n2">
	                <div class="col-xl-12 col-md-12 col-sm-12 col-12 pl-2 pr-2">
	                  <div class="form-group">
	                    <div class="formgroupinner">
	                      <i class="icon icon-phone"></i>
	                      <input type="text" class="form-control" placeholder="name" name="name" id="name">
	                    </div>
	                  </div>
	                </div>
	                <div class="col-xl-12 col-md-12 col-sm-12 col-12 pl-2 pr-2">
	                  <div class="form-group">
	                    <div class="formgroupinner">
	                      <i class="icon icon-phone"></i>
	                      <input type="text" class="form-control" placeholder="Category" name="category">
	                    </div>
	                  </div>
	                </div>
	                <div class="col-xl-12 col-md-12 col-sm-12 col-12 pl-2 pr-2">
	                  <div class="form-group">
	                    <div class="formgroupinner">
	                      <i class="icon icon-phone"></i>
	                      <input type="text" class="form-control" placeholder="price" id="price" name="price">
	                    </div>
	                  </div>
	                </div>
	                <div class="col-xl-12 col-md-12 col-sm-12 col-12 pl-2 pr-2">
	                  <div class="form-group">
	                    <div class="formgroupinner">
	                      <i class="fa fa-envelope-o"></i>
	                      <input type="text" class="form-control" name="country" placeholder="Country">
	                    </div>
	                  </div>
	                </div>
	                <div class="col-xl-12 col-md-12 col-sm-12 col-12 pl-2 pr-2">
	                  <div class="form-group">
	                    <div class="formgroupinner">
	                      <i class="icon icon-password"></i>
	                      <input type="text" class="form-control" placeholder="State" name="state" id="state">
	                    </div>
	                  </div>
	                </div>
	                 <div class="col-xl-12 col-md-12 col-sm-12 col-12 pl-2 pr-2">
	                  <div class="form-group">
	                    <div class="formgroupinner">
	                      <i class="icon icon-password"></i>
	                      <input type="text" class="form-control" placeholder="City" name="city" id="city">
	                    </div>
	                  </div>
	                </div>
	                <div class="col-xl-12 col-md-12 col-sm-12 col-12 pl-2 pr-2">
	                  <div class="form-group">
	                    <div class="formgroupinner">
	                      <i class="icon icon-edit"></i>
	                      <textarea class="form-control" placeholder="Short Description" id="description" name="description"></textarea>
	                    </div>
	                  </div>
	                </div>
	                <div class="col-xl-12 col-md-12 col-sm-12 col-12 pl-2 pr-2">
	                  <div class="form-group">
	                    <div class="formgroupinner">
	                      <i class="icon icon-edit"></i>
	                      <textarea class="form-control" placeholder="Description" id="description" name="description"></textarea>
	                    </div>
	                  </div>
	                </div>
	                 <div class="col-xl-12 col-md-12 col-sm-12 col-12 pl-2 pr-2">
	                  <div class="form-group">
	                    <div class="formgroupinner">
	                      <i class="icon icon-password"></i>
	                      <input type="file" class="form-control" name="image" id="image">
	                    </div>
	                  </div>
	                </div>
	                <div class="col-xl-12 col-md-12 col-sm-12 col-12 pl-2 pr-2">
	                  <button class="updatebtn" type="submit">Update</button>
	                </div>
	              </div>
	            </div>
	            </form>
	          </div>
	        </div>
	        </div>
	        </div>
	    </div>
	  </div>
	</div>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.default', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>