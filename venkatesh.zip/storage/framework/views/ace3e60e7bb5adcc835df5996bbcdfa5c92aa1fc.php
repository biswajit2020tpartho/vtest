<div class="navigationinner">
    <div class="container">
      <div class="row">
        <div class="col-12">
          <div class="navigation">
            <div class="navigationbox">
              <div class="navuser">
                <div class="userimg">
                  <img src="images/logo-icon.png" alt="Logo">
                </div>
                <h3>GX9</h3>
                <p>Your digital guru for buy / sell</p>
              </div>
              <ul class="sf-menu">
                <li class="active"><a href="javascript:void(0);">Home</a></li>
                <li><a href="javascript:void(0);">Cars</a></li>
                <li><a href="javascript:void(0);">Motorcycles</a></li>
                <li><a href="javascript:void(0);">Mobile Phones</a></li>
                <li><a href="javascript:void(0);">Scooters</a></li>
                <li><a href="javascript:void(0);">Commercial Vehicles</a></li>
                <li><a href="javascript:void(0);">House for Rent</a></li>
                <li><a href="javascript:void(0);">House For Sale</a></li>
                <li><a href="javascript:void(0);">Furniture</a></li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>