    

    <?php $__env->startSection('content'); ?>

    <div class="dashboard">
	  <div class="dashboardcontainer">
	    <div class="afterloginnavigation">
	      <div class="usercolumn">
	        <div class="userimg">
	        <?php if($userDetails->photo): ?>
	          <img src="<?php echo e(url('/')); ?>/<?php echo e($userDetails->photo); ?>" alt="User Image">
	        <?php else: ?>
	          <img src="<?php echo e(url('/')); ?>/images/user-noimage.jpg" alt="User Image">
	        <?php endif; ?>
	        </div>
	        <h3><?php echo e($userDetails->name); ?></h3>
	        <!-- <p>Visual artist</p> -->
	      </div>
	      <div class="usernavlist">
	         <?php echo $__env->make('layout.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?> 
	      </div>
	    </div>
	    <div class="layoutcontainer">
	      <div class="layoutcontent">
	        <div class="layoutcontentinner">
	          <div class="afterrightbox">
	          <a class="profilebtn" href="javascript:void(0);"><i class="icon icon-user"></i><span>Profile Nav</span></a>
	          <h3>Dashboard / Update Account</h3>
	          <div class="row">
	          	 <?php if(Session::has('error_message')): ?>
              <div class="alert <?php echo e(Session::get('alert-class', 'alert-danger alert-dismissible')); ?>"><?php echo e(Session::get('error_message')); ?><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button></div>
              <?php endif; ?> 
              <?php if(Session::has('success_message')): ?>
              <div class="alert <?php echo e(Session::get('alert-class', 'alert-success alert-dismissible')); ?>"><?php echo e(Session::get('success_message')); ?><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button></div>
              <?php endif; ?> 
               <?php if($errors->any()): ?>
              <div class="alert alert-danger">
                <ul>
                  <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
              </div>
              <?php endif; ?>
	          	<form name="" method="post" action="<?php echo e(url('en/user-update')); ?>" enctype="multipart/form-data">
	          	<?php echo csrf_field(); ?>
	          	<input type="hidden" name="user_id" value="<?php echo e($userDetails->id); ?>">
	            <div class="col-xl-9 col-md-11 col-sm-12 col-12">
	              <fieldset class="userviewsec">
	                <legend>User Name</legend>
	                <p><i class="icon icon-user"></i><?php echo e($userDetails->name); ?></p>
	              </fieldset>
	              <div class="row ml-n2 mr-n2">
	                <div class="col-xl-6 col-md-12 col-sm-12 col-12 pl-2 pr-2">
	                  <div class="form-group">
	                    <div class="formgroupinner">
	                      <i class="icon icon-phone"></i>
	                      <input type="text" class="form-control" placeholder="User Name" name="user_name" value="<?php echo e($userDetails->name); ?>">
	                    </div>
	                  </div>
	                </div>
	                <div class="col-xl-6 col-md-12 col-sm-12 col-12 pl-2 pr-2">
	                  <div class="form-group">
	                    <div class="formgroupinner">
	                      <i class="icon icon-phone"></i>
	                      <input type="text" class="form-control" placeholder="Mobile Number" name="phone_number" value="<?php echo e($userDetails->phone_number); ?>">
	                    </div>
	                  </div>
	                </div>
	                <div class="col-xl-12 col-md-12 col-sm-12 col-12 pl-2 pr-2">
	                  <div class="form-group">
	                    <div class="formgroupinner">
	                      <i class="fa fa-envelope-o"></i>
	                      <input type="email" class="form-control" name="email" value="<?php echo e($userDetails->email); ?>" readonly="">
	                    </div>
	                  </div>
	                </div>
	                <div class="col-xl-12 col-md-12 col-sm-12 col-12 pl-2 pr-2">
	                  <div class="form-group">
	                    <div class="formgroupinner">
	                      <i class="icon icon-password"></i>
	                      <input type="password" class="form-control" placeholder="Password" name="user_password" id="user_password">
	                    </div>
	                  </div>
	                </div>
	                <div class="col-xl-12 col-md-12 col-sm-12 col-12 pl-2 pr-2">
	                  <div class="form-group">
	                    <div class="formgroupinner">
	                      <i class="icon icon-edit"></i>
	                      <textarea class="form-control" placeholder="Description" id="description" name="description"><?php echo e($userDetails->description); ?></textarea>
	                    </div>
	                  </div>
	                </div>
	                <div class="col-xl-12 col-md-12 col-sm-12 col-12 pl-2 pr-2">
	                  <div class="form-group inputfile">
	                    <div class="formgroupinner">
	                      <input type="file" class="form-control" name="user_image" id="user_image">
	                    </div>
	                  </div>
	                </div>
	                <div class="col-xl-12 col-md-12 col-sm-12 col-12 pl-2 pr-2">
	                  <button class="updatebtn" type="submit">Update</button>
	                </div>
	              </div>
	            </div>
	            </form>
	          </div>
	        </div>
	        </div>
	        </div>
	    </div>
	  </div>
	</div>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.default', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>