<div class="headerinner">
    <div class="headerinnertop">
      <div class="container">
        <div class="headtoprow">
          <div class="logocontainer">
            <div class="logoinner">
              <a href="index.html"><img src="images/logo.jpg" alt="" /></a>
            </div>
          </div>
          <div class="rightuserbox">
            <a href="javascript:void(0);" class="loginbtn"><i class="fa fa-user"></i><span>login</span></a>
            <a href="javascript:void(0);" class="sellbtn"><i class="fa fa-camera"></i><span>Sell</span></a>
            <div class="lanbox dropdown">
              <a id="dLabel" data-target="#" href="http://example.com/" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><span class="lanspan"><span class="flag-icon flag-icon-gb"></span></span></a>
              <ul class="dropdown-menu" aria-labelledby="dLabel">
                <li><a class="dropdown-item" href="#gb"><span class="flag-icon flag-icon-gb"> </span></a></li>
                <li><a class="dropdown-item" href="#us"><span class="flag-icon flag-icon-us"> </span></a></li>
                <li><a class="dropdown-item" href="#au"><span class="flag-icon flag-icon-au"> </span></a></li>
              </ul>
            </div>
            <div class="socialtop">
              <a href="javascript:void(0);"><i class="fa fa-facebook"></i></a>
              <a href="javascript:void(0);"><i class="fa fa-twitter"></i></a>
              <a href="javascript:void(0);"><i class="fa fa-youtube"></i></a>
              <a href="javascript:void(0);"><i class="fa fa-pinterest-p"></i></a>
            </div>
            <a href="javascript:void(0);" class="NavBar"><i class="icon icon-segment"></i></a>
          </div>
        </div>
      </div>
    </div>
  </div>