    

    <?php $__env->startSection('content'); ?>
    <section class="bannercontainer">
        <div id="HomeBanner" class="owl-carousel owl-theme">
            <div class="item">
            <img class="owl-lazy" data-src="images/banner1.jpg" alt="" />
            </div>
            <div class="item">
            <img class="owl-lazy" data-src="images/banner1.jpg" alt="" />
            </div>
            <div class="item">
            <img class="owl-lazy" data-src="images/banner1.jpg" alt="" />
            </div>
            <div class="item">
            <img class="owl-lazy" data-src="images/banner1.jpg" alt="" />
            </div>
        </div>
        <div class="bannersearchouter">
            <div class="container">
            <div class="row">
                <div class="col-12">
                <div class="binnerouter">
                    <div class="row">
                    <div class="col-12 wow fadeInDown">
                        <h1>Your digital guru for buy/ sell</h1>
                        <p>Buy / Sell anywhere anytime, at your own comfort</p>
                    </div>
                    </div>
                    <div class="row">
                    <div class="col-12">
                        <div class="bannersearchbx wow fadeInUp">
                        <div class="row ml-n1 mr-n1">
                            <div class="searchcolumn">
                            <div class="form-group">
                                <select class="form-control">
                                <option selected="" hidden="">Ad category</option>
                                <option>Lorem ipsum dolor sit</option>
                                <option>Quisque varius erat</option>
                                <option>Sed nec leo quis diam</option>
                                </select>
                            </div>
                            </div>
                            <div class="searchcolumn">
                            <div class="form-group">
                                <i class="fa fa-map-marker"></i>
                                <input type="text" class="form-control" placeholder="Location" name="">
                            </div>
                            </div>
                            <div class="searchcolumn">
                            <div class="form-group">
                                <input type="text" class="form-control" placeholder="Keyword" name="">
                            </div>
                            </div>
                            <div class="searchcolumn">
                            <div class="form-group">
                                <select class="form-control">
                                <option selected="" hidden="">Price</option>
                                <option>$1000</option>
                                <option>$1500</option>
                                <option>$2000</option>
                                </select>
                            </div>
                            </div>
                            <div class="searchbtncolumn">
                            <button class="searchbtn"><i class="fa fa-search"></i><span>Search</span></button>
                            </div>
                        </div>
                        </div>
                    </div>
                    </div>
                </div>
                </div>
            </div>
            </div>
        </div>
    </section>

    <section class="featuredcatcontainer">
    <div class="container">
        <div class="row">
        <div class="col-12 wow fadeInDown">
            <h2>Featured categories</h2>
        </div>
        </div>
        <div class="row">
        <div class="col-12">
            <div id="FeaturedCategories" class="owl-carousel owl-theme">
            <div class="item wow fadeInDown">
                <div class="fcatebox">
                <div class="fcateboxouter">
                    <div class="fcateboxinner">
                    <div class="fcateicon"><img src="images/icon1.png" alt="" /></div>
                    <div class="fcatetext">Real Estate</div>
                    </div>
                </div>
                </div>
            </div>
            <div class="item wow fadeInDown">
                <div class="fcatebox">
                <div class="fcateboxouter">
                    <div class="fcateboxinner">
                    <div class="fcateicon"><img src="images/icon2.png" alt="" /></div>
                    <div class="fcatetext">Vehicles</div>
                    </div>
                </div>
                </div>
            </div>
            <div class="item wow fadeInDown">
                <div class="fcatebox">
                <div class="fcateboxouter">
                    <div class="fcateboxinner">
                    <div class="fcateicon"><img src="images/icon3.png" alt="" /></div>
                    <div class="fcatetext">Mobile Phone</div>
                    </div>
                </div>
                </div>
            </div>
            <div class="item wow fadeInDown">
                <div class="fcatebox">
                <div class="fcateboxouter">
                    <div class="fcateboxinner">
                    <div class="fcateicon"><img src="images/icon4.png" alt="" /></div>
                    <div class="fcatetext">Furniture</div>
                    </div>
                </div>
                </div>
            </div>
            <div class="item wow fadeInDown">
                <div class="fcatebox">
                <div class="fcateboxouter">
                    <div class="fcateboxinner">
                    <div class="fcateicon"><img src="images/icon5.png" alt="" /></div>
                    <div class="fcatetext">Electronics</div>
                    </div>
                </div>
                </div>
            </div>
            <div class="item wow fadeInDown">
                <div class="fcatebox">
                <div class="fcateboxouter">
                    <div class="fcateboxinner">
                    <div class="fcateicon"><img src="images/icon6.png" alt="" /></div>
                    <div class="fcatetext">Job</div>
                    </div>
                </div>
                </div>
            </div>
            <div class="item wow fadeInDown">
                <div class="fcatebox">
                <div class="fcateboxouter">
                    <div class="fcateboxinner">
                    <div class="fcateicon"><img src="images/icon7.png" alt="" /></div>
                    <div class="fcatetext">Fashion</div>
                    </div>
                </div>
                </div>
            </div>
            <div class="item wow fadeInDown">
                <div class="fcatebox">
                <div class="fcateboxouter">
                    <div class="fcateboxinner">
                    <div class="fcateicon"><img src="images/icon8.png" alt="" /></div>
                    <div class="fcatetext">Education</div>
                    </div>
                </div>
                </div>
            </div>
            <div class="item wow fadeInDown">
                <div class="fcatebox">
                <div class="fcateboxouter">
                    <div class="fcateboxinner">
                    <div class="fcateicon"><img src="images/icon1.png" alt="" /></div>
                    <div class="fcatetext">Real Estate</div>
                    </div>
                </div>
                </div>
            </div>
            <div class="item wow fadeInDown">
                <div class="fcatebox">
                <div class="fcateboxouter">
                    <div class="fcateboxinner">
                    <div class="fcateicon"><img src="images/icon2.png" alt="" /></div>
                    <div class="fcatetext">Vehicles</div>
                    </div>
                </div>
                </div>
            </div>
            <div class="item wow fadeInDown">
                <div class="fcatebox">
                <div class="fcateboxouter">
                    <div class="fcateboxinner">
                    <div class="fcateicon"><img src="images/icon3.png" alt="" /></div>
                    <div class="fcatetext">Mobile Phone</div>
                    </div>
                </div>
                </div>
            </div>
            <div class="item wow fadeInDown">
                <div class="fcatebox">
                <div class="fcateboxouter">
                    <div class="fcateboxinner">
                    <div class="fcateicon"><img src="images/icon4.png" alt="" /></div>
                    <div class="fcatetext">Furniture</div>
                    </div>
                </div>
                </div>
            </div>
            <div class="item wow fadeInDown">
                <div class="fcatebox">
                <div class="fcateboxouter">
                    <div class="fcateboxinner">
                    <div class="fcateicon"><img src="images/icon5.png" alt="" /></div>
                    <div class="fcatetext">Electronics</div>
                    </div>
                </div>
                </div>
            </div>
            <div class="item wow fadeInDown">
                <div class="fcatebox">
                <div class="fcateboxouter">
                    <div class="fcateboxinner">
                    <div class="fcateicon"><img src="images/icon6.png" alt="" /></div>
                    <div class="fcatetext">Job</div>
                    </div>
                </div>
                </div>
            </div>
            <div class="item wow fadeInDown">
                <div class="fcatebox">
                <div class="fcateboxouter">
                    <div class="fcateboxinner">
                    <div class="fcateicon"><img src="images/icon7.png" alt="" /></div>
                    <div class="fcatetext">Fashion</div>
                    </div>
                </div>
                </div>
            </div>
            <div class="item wow fadeInDown">
                <div class="fcatebox">
                <div class="fcateboxouter">
                    <div class="fcateboxinner">
                    <div class="fcateicon"><img src="images/icon8.png" alt="" /></div>
                    <div class="fcatetext">Education</div>
                    </div>
                </div>
                </div>
            </div>
            </div>
        </div>
        </div>
    </div>
    </section>

    <section class="topadcontainer">
    <div class="container">
        <div class="row justify-content-center">
        <div class="col-xl-5 col-md-5 col-sm-12 col-12 mb-3 wow fadeInDown">
            <div class="topadbox">
            <a href="javascript:void(0);"><img src="images/ad1.jpg" alt="" /></a>
            </div>
        </div>
        <div class="col-xl-5 col-md-5 col-sm-12 col-12 mb-3 wow fadeInDown">
            <div class="topadbox">
            <a href="javascript:void(0);"><img src="images/ad2.jpg" alt="" /></a>
            </div>
        </div>
        </div>
    </div>
    </section>

    <section class="featuredadcontainer">
    <div class="container">
        <div class="row">
        <div class="col-12 wow fadeInDown">
            <h2>FEATURED ADS</h2>
        </div>
        </div>
        <div class="row ml-n2 mr-n2">
        <div class="col-xl-3 col-md-4 col-sm-6 col-12 pl-2 pr-2 mb-4 wow fadeInDown">
            <div class="featuredadbox">
            <div class="featuredadimg">
                <img src="images/img1.jpg" alt="" />
                <span class="featuredtag">Featured</span>
                <div class="featuredovarlay">
                <div class="ratinginner">
                    <div class="starrating">
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    </div>
                    <div class="heartbx">
                    <a href="javascript:void(0);"><i class="fa fa-heart"></i></a>
                    </div>
                </div>
                </div>
            </div>
            <div class="featuredadcontent">
                <div class="catename">Mobile Phone</div>
                <div class="catecontent">
                <h3>consectetur adipiscing elit</h3>
                <div class="location">
                    <i class="fa fa-map-marker"></i>
                    Washington State, USA
                </div>
                <div class="pricebx">
                    <div class="price"><i class="fa fa-euro"></i>20.00</div>
                    <div class="posteddate">Posted: 25-02-2020</div>
                </div>
                </div>
            </div>
            </div>
        </div>
        <div class="col-xl-3 col-md-4 col-sm-6 col-12 pl-2 pr-2 mb-4 wow fadeInDown">
            <div class="featuredadbox">
            <div class="featuredadimg">
                <img src="images/img2.jpg" alt="" />
                <div class="featuredovarlay">
                <div class="ratinginner">
                    <div class="starrating">
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    </div>
                    <div class="heartbx">
                    <a href="javascript:void(0);"><i class="fa fa-heart"></i></a>
                    </div>
                </div>
                </div>
            </div>
            <div class="featuredadcontent">
                <div class="catename">Vehicles</div>
                <div class="catecontent">
                <h3>consectetur adipiscing elit</h3>
                <div class="location">
                    <i class="fa fa-map-marker"></i>
                    Washington State, USA
                </div>
                <div class="pricebx">
                    <div class="price"><i class="fa fa-euro"></i>20.00</div>
                    <div class="posteddate">Posted: 25-02-2020</div>
                </div>
                </div>
            </div>
            </div>
        </div>
        <div class="col-xl-3 col-md-4 col-sm-6 col-12 pl-2 pr-2 mb-4 wow fadeInDown">
            <div class="featuredadbox">
            <div class="featuredadimg">
                <img src="images/img3.jpg" alt="" />
                <span class="featuredtag">Featured</span>
                <div class="featuredovarlay">
                <div class="ratinginner">
                    <div class="starrating">
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    </div>
                    <div class="heartbx">
                    <a href="javascript:void(0);"><i class="fa fa-heart"></i></a>
                    </div>
                </div>
                </div>
            </div>
            <div class="featuredadcontent">
                <div class="catename">Furniture</div>
                <div class="catecontent">
                <h3>consectetur adipiscing elit</h3>
                <div class="location">
                    <i class="fa fa-map-marker"></i>
                    Washington State, USA
                </div>
                <div class="pricebx">
                    <div class="price"><i class="fa fa-euro"></i>20.00</div>
                    <div class="posteddate">Posted: 25-02-2020</div>
                </div>
                </div>
            </div>
            </div>
        </div>
        <div class="col-xl-3 col-md-4 col-sm-6 col-12 pl-2 pr-2 mb-4 wow fadeInDown">
            <div class="featuredadbox">
            <div class="featuredadimg">
                <img src="images/img4.jpg" alt="" />
                <span class="featuredtag">Featured</span>
                <div class="featuredovarlay">
                <div class="ratinginner">
                    <div class="starrating">
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    </div>
                    <div class="heartbx">
                    <a href="javascript:void(0);"><i class="fa fa-heart"></i></a>
                    </div>
                </div>
                </div>
            </div>
            <div class="featuredadcontent">
                <div class="catename">Electronics</div>
                <div class="catecontent">
                <h3>consectetur adipiscing elit</h3>
                <div class="location">
                    <i class="fa fa-map-marker"></i>
                    Washington State, USA
                </div>
                <div class="pricebx">
                    <div class="price"><i class="fa fa-euro"></i>20.00</div>
                    <div class="posteddate">Posted: 25-02-2020</div>
                </div>
                </div>
            </div>
            </div>
        </div>
        <div class="col-xl-3 col-md-4 col-sm-6 col-12 pl-2 pr-2 mb-4 wow fadeInDown">
            <div class="featuredadbox">
            <div class="featuredadimg">
                <img src="images/img5.jpg" alt="" />
                <span class="featuredtag">Featured</span>
                <div class="featuredovarlay">
                <div class="ratinginner">
                    <div class="starrating">
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    </div>
                    <div class="heartbx">
                    <a href="javascript:void(0);"><i class="fa fa-heart"></i></a>
                    </div>
                </div>
                </div>
            </div>
            <div class="featuredadcontent">
                <div class="catename">Fashion</div>
                <div class="catecontent">
                <h3>consectetur adipiscing elit</h3>
                <div class="location">
                    <i class="fa fa-map-marker"></i>
                    Washington State, USA
                </div>
                <div class="pricebx">
                    <div class="price"><i class="fa fa-euro"></i>20.00</div>
                    <div class="posteddate">Posted: 25-02-2020</div>
                </div>
                </div>
            </div>
            </div>
        </div>
        <div class="col-xl-3 col-md-4 col-sm-6 col-12 pl-2 pr-2 mb-4 wow fadeInDown">
            <div class="featuredadbox">
            <div class="featuredadimg">
                <img src="images/img6.jpg" alt="" />
                <div class="featuredovarlay">
                <div class="ratinginner">
                    <div class="starrating">
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    </div>
                    <div class="heartbx">
                    <a href="javascript:void(0);"><i class="fa fa-heart"></i></a>
                    </div>
                </div>
                </div>
            </div>
            <div class="featuredadcontent">
                <div class="catename">Education</div>
                <div class="catecontent">
                <h3>consectetur adipiscing elit</h3>
                <div class="location">
                    <i class="fa fa-map-marker"></i>
                    Washington State, USA
                </div>
                <div class="pricebx">
                    <div class="price"><i class="fa fa-euro"></i>20.00</div>
                    <div class="posteddate">Posted: 25-02-2020</div>
                </div>
                </div>
            </div>
            </div>
        </div>
        <div class="col-xl-3 col-md-4 col-sm-6 col-12 pl-2 pr-2 mb-4 wow fadeInDown">
            <div class="featuredadbox">
            <div class="featuredadimg">
                <img src="images/img7.jpg" alt="" />
                <div class="featuredovarlay">
                <div class="ratinginner">
                    <div class="starrating">
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    </div>
                    <div class="heartbx">
                    <a href="javascript:void(0);"><i class="fa fa-heart"></i></a>
                    </div>
                </div>
                </div>
            </div>
            <div class="featuredadcontent">
                <div class="catename">Car</div>
                <div class="catecontent">
                <h3>consectetur adipiscing elit</h3>
                <div class="location">
                    <i class="fa fa-map-marker"></i>
                    Washington State, USA
                </div>
                <div class="pricebx">
                    <div class="price"><i class="fa fa-euro"></i>20.00</div>
                    <div class="posteddate">Posted: 25-02-2020</div>
                </div>
                </div>
            </div>
            </div>
        </div>
        <div class="col-xl-3 col-md-4 col-sm-6 col-12 pl-2 pr-2 mb-4 wow fadeInDown">
            <div class="featuredadbox">
            <div class="featuredadimg">
                <img src="images/img8.jpg" alt="" />
                <span class="featuredtag">Featured</span>
                <div class="featuredovarlay">
                <div class="ratinginner">
                    <div class="starrating">
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    </div>
                    <div class="heartbx">
                    <a href="javascript:void(0);"><i class="fa fa-heart"></i></a>
                    </div>
                </div>
                </div>
            </div>
            <div class="featuredadcontent">
                <div class="catename">Houses & Apartments For Sale</div>
                <div class="catecontent">
                <h3>consectetur adipiscing elit</h3>
                <div class="location">
                    <i class="fa fa-map-marker"></i>
                    Washington State, USA
                </div>
                <div class="pricebx">
                    <div class="price"><i class="fa fa-euro"></i>20.00</div>
                    <div class="posteddate">Posted: 25-02-2020</div>
                </div>
                </div>
            </div>
            </div>
        </div>
        </div>
        <div class="row">
        <div class="col-12 text-center wow fadeInDown">
            <a href="javascript:void(0);" class="viewallbtn"><span>view all</span><i class="icon icon-arrow-thin-right"></i></a>
        </div>
        </div>
    </div>
    </section>

    <section class="topad2container">
    <div class="container">
        <div class="row justify-content-center">
        <div class="col-xl-6 col-md-6 col-sm-12 col-12 mb-3 wow fadeInDown">
            <div class="topadbox">
            <a href="javascript:void(0);"><img src="images/ad3.jpg" alt="" /></a>
            </div>
        </div>
        <div class="col-xl-6 col-md-6 col-sm-12 col-12 mb-3 align-self-end wow fadeInDown">
            <div class="topadbox">
            <a href="javascript:void(0);"><img src="images/ad4.jpg" alt="" /></a>
            </div>
        </div>
        </div>
    </div>
    </section>

    <section class="howitcontainer">
    <div class="howitcontainerinner">
        <div class="container">
        <div class="row">
            <div class="col-12 zindex2 wow fadeInDown">
            <h2>How it works</h2>
            </div>
        </div>
        <div class="row justify-content-center">
            <div class="col-xl-10 col-md-12 col-sm-12 col-12 zindex2">
            <div class="row justify-content-center">
                <div class="col-xl-3 col-md-3 col-sm-6 col-12 howitcolumn text-center wow fadeInDown">
                <div class="howitbox">
                    <div class="howitboxouter">
                    <div class="howitboxinner">
                        <div class="howiticon"><img src="images/create-account.png" alt="" /></div>
                        <div class="howittext">Create Account</div>
                    </div>
                    </div>
                </div>
                </div>
                <div class="col-xl-3 col-md-3 col-sm-6 col-12 howitcolumn text-center wow fadeInDown">
                <div class="howitbox">
                    <div class="howitboxouter">
                    <div class="howitboxinner">
                        <div class="howiticon"><img src="images/purchase-package.png" alt="" /></div>
                        <div class="howittext">Purchase Package</div>
                    </div>
                    </div>
                </div>
                </div>
                <div class="col-xl-3 col-md-3 col-sm-6 col-12 howitcolumn text-center wow fadeInDown">
                <div class="howitbox">
                    <div class="howitboxouter">
                    <div class="howitboxinner">
                        <div class="howiticon"><img src="images/create-wallet.png" alt="" /></div>
                        <div class="howittext">Create Wallet</div>
                    </div>
                    </div>
                </div>
                </div>
                <div class="col-xl-3 col-md-3 col-sm-6 col-12 howitcolumn text-center wow fadeInDown">
                <div class="howitbox">
                    <div class="howitboxouter">
                    <div class="howitboxinner">
                        <div class="howiticon"><img src="images/post-a-new-ad.png" alt="" /></div>
                        <div class="howittext">Post A New Ad</div>
                    </div>
                    </div>
                </div>
                </div>
            </div>
            </div>
        </div>
        </div>
    </div>
    </section>

    <section class="explorelocationcontainer">
    <div class="container">
        <div class="row">
        <div class="col-12 wow fadeInDown">
            <h2>Explore LocationS</h2>
        </div>
        </div>
        <div class="row ml-n2 mr-n2">
        <div class="col-xl-3 col-md-4 col-sm-6 col-12 pl-2 pr-2 mb-4 wow fadeInDown">
            <div class="explorelocationbox">
            <div class="explorelocationimg">
                <img src="images/img9.jpg" alt="" />
                <div class="exploreheading">United Kingdom</div>
            </div>
            </div>
        </div>
        <div class="col-xl-3 col-md-4 col-sm-6 col-12 pl-2 pr-2 mb-4 wow fadeInDown">
            <div class="explorelocationbox">
            <div class="explorelocationimg">
                <img src="images/img10.jpg" alt="" />
                <div class="exploreheading">China</div>
            </div>
            </div>
        </div>
        <div class="col-xl-3 col-md-4 col-sm-6 col-12 pl-2 pr-2 mb-4 wow fadeInDown">
            <div class="explorelocationbox">
            <div class="explorelocationimg">
                <img src="images/img11.jpg" alt="" />
                <div class="exploreheading">Australia</div>
            </div>
            </div>
        </div>
        <div class="col-xl-3 col-md-4 col-sm-6 col-12 pl-2 pr-2 mb-4 wow fadeInDown">
            <div class="explorelocationbox">
            <div class="explorelocationimg">
                <img src="images/img12.jpg" alt="" />
                <div class="exploreheading">France</div>
            </div>
            </div>
        </div>
        </div>
    </div>
    </section>

    <section class="aboutcontainer">
    <div class="aboutcontainerinner">
        <div class="container">
        <div class="row justify-content-end">
            <div class="col-xl-5 col-md-7 col-sm-12 col-12 wow fadeInDown">
            <div class="aboutcontent">
                <h2>About G9X</h2>
                <h5>Your Digital Guru For Buy/ Sell</h5>
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiu smod tempor incididunt ut labore et dolore magna aliqua. Quis ipsum suspendisse ultrices gravida. Risus commodo.</p>
                <a href="javascript:void(0);" class="viewallbtn"><span>view all</span><i class="icon icon-arrow-thin-right"></i></a>
            </div>
            </div>
        </div>
        </div>
    </div>
    </section>


    <section class="downloadappcontainer">
    <div class="container">
        <div class="row">
        <div class="col-xl-6 col-md-6 col-sm-6 col-12 align-self-center wow fadeInDown">
            <div class="mobileappbx">
            <h2>Download this app</h2>
            <h5>Consectetur adipiscing elit, sed do eiu</h5>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiu smod tempor incididunt ut labore et dolore magna aliqua. Quis ipsum suspendisse ultrices gravida. Risus commodo.</p>
            <a href="javascript:void(0);" class="appbtn"><img src="images/apple-store.png" alt="Apple Store"></a>
            <a href="javascript:void(0);" class="appbtn"><img src="images/android-store.png" alt="Android Store"></a>
            </div>
        </div>
        <div class="col-xl-6 col-md-6 col-sm-6 col-12 align-self-end wow fadeInUp">
            <div class="mobileappimg">
            <span><img src="images/mobile-app-img.png" alt="" /></span>
            </div>
        </div>
        </div>
    </div>
    </section>
    <?php $__env->stopSection(); ?>


    
<?php echo $__env->make('layout.default', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>