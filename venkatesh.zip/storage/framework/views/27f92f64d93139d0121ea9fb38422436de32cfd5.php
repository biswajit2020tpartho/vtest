    

    <?php $__env->startSection('content'); ?>
    <section class="bannercontainer">
        <div id="HomeBanner" class="owl-carousel owl-theme">
            <?php $__currentLoopData = $getBanner; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="item">
            <img class="owl-lazy" data-src="<?php echo e(url('/')); ?>/<?php echo e($banner->image); ?>" alt="<?php echo e($banner->title); ?>" />
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            

        </div>

        <div class="bannersearchouter">
            <div class="container">
            <div class="row">
                <div class="col-12">
                <div class="binnerouter">
                    <div class="row">
                    <div class="col-12 wow fadeInDown">
                        <h1><?php echo app('translator')->getFromJson('home.banner_txt_1'); ?></h1>
                        <p><?php echo app('translator')->getFromJson('home.banner_txt_2'); ?></p>
                    </div>
                    </div>
                    <div class="row">
                    <div class="col-12">
                        <div class="bannersearchbx wow fadeInUp">
                        <div class="row ml-n1 mr-n1">
                            <div class="searchcolumn">
                            <div class="form-group">
                                <select class="form-control">
                                <option selected="" hidden=""><?php echo app('translator')->getFromJson('home.ads_cat_txt'); ?></option>
                                <?php $__currentLoopData = $categorie; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($cat->id); ?>"><?php echo e($cat->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                                
                                </select>
                            </div>
                            </div>
                            <div class="searchcolumn">
                            <div class="form-group">
                                <i class="fa fa-map-marker"></i>
                                <input type="text" class="form-control" placeholder="<?php echo app('translator')->getFromJson('home.loc_txt'); ?>" name="">
                            </div>
                            </div>
                            <div class="searchcolumn">
                            <div class="form-group">
                                <input type="text" class="form-control" placeholder="<?php echo app('translator')->getFromJson('home.key_txt'); ?>" name="">
                            </div>
                            </div>
                            <div class="searchcolumn">
                            <div class="form-group">
                                <select class="form-control">
                                <option selected="" hidden=""><?php echo app('translator')->getFromJson('home.price_txt'); ?></option>
                                <option>$1000</option>
                                <option>$1500</option>
                                <option>$2000</option>
                                </select>
                            </div>
                            </div>
                            <div class="searchbtncolumn">
                            <button class="searchbtn"><i class="fa fa-search"></i><span><?php echo app('translator')->getFromJson('home.search_txt'); ?></span></button>
                            </div>
                        </div>
                        </div>
                    </div>
                    </div>
                </div>
                </div>
            </div>
            </div>
        </div>
    </section>
    <section class="featuredcatcontainer">
    <div class="container">
        <div class="row">
        <div class="col-12 wow fadeInDown">
            <h2><?php echo app('translator')->getFromJson('home.feature_cat_txt'); ?></h2>
        </div>
        </div>
        <div class="row">
        <div class="col-12">
            <div id="FeaturedCategories" class="owl-carousel owl-theme">
            <?php $__currentLoopData = $featureCategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
             <a href="<?php echo e(url(app()->getLocale().'/all-ads')); ?>/<?php echo e($category->getPageslug->slug); ?>"><div class="item wow fadeInDown">
                <div class="fcatebox">
                <div class="fcateboxouter">
                    <div class="fcateboxinner">
                    <div class="fcateicon"><img src="<?php echo e(url('/')); ?>/<?php echo e($category->image); ?>" alt="" /></div>
                   <div class="fcatetext"><?php echo e($category->name); ?></div>
                    </div>
                </div>
                </div>
            </div></a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
        </div>
    </div>
    </section>

    <section class="topadcontainer">
    <div class="container">
        <div class="row justify-content-center">
        <div class="col-xl-5 col-md-5 col-sm-12 col-12 mb-3 wow fadeInDown">
            <div class="topadbox">
            <a href="javascript:void(0);"><img src="images/ad1.jpg" alt="" /></a>
            </div>
        </div>
        <div class="col-xl-5 col-md-5 col-sm-12 col-12 mb-3 wow fadeInDown">
            <div class="topadbox">
            <a href="javascript:void(0);"><img src="images/ad2.jpg" alt="" /></a>
            </div>
        </div>
        </div>
    </div>
    </section>

    <section class="featuredadcontainer">
    <div class="container">
        <div class="row">
        <div class="col-12 wow fadeInDown">
            <h2><?php echo app('translator')->getFromJson('home.feature_ads_txt'); ?></h2>
        </div>
        </div>
        <div class="row ml-n2 mr-n2">
        <?php $__currentLoopData = $advertisement; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ads): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-xl-3 col-md-4 col-sm-6 col-12 pl-2 pr-2 mb-4 wow fadeInDown">
            <div class="featuredadbox">
            <div class="featuredadimg">
                <img src="<?php echo e(url('/')); ?>/<?php echo e($ads->images); ?>" alt="" />
                <span class="featuredtag">Featured</span>
                <div class="featuredovarlay">
                <div class="ratinginner">
                    <div class="starrating">
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    </div>
                    <div class="heartbx" id="heartbx_<?php echo e($ads->id); ?>">                        
                        <?php if(count($ads->getAdvtwishlist)>0): ?>
                        <a href="javascript:void(0);" onclick="wishlist.add('<?php echo e($ads->id); ?>');"><i class="fa fa-heart"></i></a>                    
                        <?php else: ?>
                        <a href="javascript:void(0);" onclick="wishlist.add('<?php echo e($ads->id); ?>');"><i class="fa fa-heart-o"></i></a>                 
                        <?php endif; ?>
                    </div>
                </div>
                </div>
            </div>
            <div class="featuredadcontent">
                <div class="catename"><?php echo e($ads->getAdvtCategory->name); ?></div>
                <div class="catecontent">
                <h3><a href="<?php echo e(url(app()->getLocale().'/adsdetails')); ?>/<?php echo e($ads->getPageslug->slug); ?>"><?php echo e($ads->title); ?></a></h3>
                <div class="location">
                    <i class="fa fa-map-marker"></i>
                    <?php echo e($ads->getAdvtStates->state_name); ?>, <?php echo e($ads->getAdvtCountry->country_name); ?>

                </div>
                <div class="pricebx">
                    <div class="price"><i class="fa fa-euro"></i><?php echo e($ads->amount); ?></div>
                    <div class="posteddate">Posted: <?php echo e(date('d-m-Y',strtotime($ads->created_at))); ?></div>
                </div>
                </div>
            </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="row">
        <div class="col-12 text-center wow fadeInDown">
            <a href="<?php echo e(url('/')); ?>/all-ads" class="viewallbtn"><span>view all</span><i class="icon icon-arrow-thin-right"></i></a>
        </div>
        </div>
    </div>
    </section>

    <section class="topad2container">
    <div class="container">
        <div class="row justify-content-center">
        <div class="col-xl-6 col-md-6 col-sm-12 col-12 mb-3 wow fadeInDown">
            <div class="topadbox">
            <a href="javascript:void(0);"><img src="images/ad3.jpg" alt="" /></a>
            </div>
        </div>
        <div class="col-xl-6 col-md-6 col-sm-12 col-12 mb-3 align-self-end wow fadeInDown">
            <div class="topadbox">
            <a href="javascript:void(0);"><img src="images/ad4.jpg" alt="" /></a>
            </div>
        </div>
        </div>
    </div>
    </section>

    <section class="howitcontainer">
    <div class="howitcontainerinner">
        <div class="container">
        <div class="row">
            <div class="col-12 zindex2 wow fadeInDown">
            <h2><?php echo app('translator')->getFromJson('home.how_it_work'); ?></h2>
            </div>
        </div>
        <div class="row justify-content-center">
            <div class="col-xl-10 col-md-12 col-sm-12 col-12 zindex2">
            <div class="row justify-content-center">
                <?php $__currentLoopData = $howit_works; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-xl-3 col-md-3 col-sm-6 col-12 howitcolumn text-center wow fadeInDown">
                    <div class="howitbox">
                        <div class="howitboxouter">
                        <div class="howitboxinner">
                            <div class="howiticon"><img src="<?php echo e(url('/')); ?>/<?php echo e($val->image); ?>" alt="<?php echo e($val->name[app()->getLocale()]); ?>" /></div>
                            <div class="howittext"><?php echo e($val->name[app()->getLocale()]); ?></div>
                        </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               
            </div>
            </div>
        </div>
        </div>
    </div>
    </section>

    <section class="explorelocationcontainer">
    <div class="container">
        <div class="row">
        <div class="col-12 wow fadeInDown">
            <h2>Explore LocationS</h2>
        </div>
        </div>
        <div class="row ml-n2 mr-n2">
        <div class="col-xl-3 col-md-4 col-sm-6 col-12 pl-2 pr-2 mb-4 wow fadeInDown">
            <div class="explorelocationbox">
            <div class="explorelocationimg">
                <img src="images/img9.jpg" alt="" />
                <div class="exploreheading">United Kingdom</div>
            </div>
            </div>
        </div>
        <div class="col-xl-3 col-md-4 col-sm-6 col-12 pl-2 pr-2 mb-4 wow fadeInDown">
            <div class="explorelocationbox">
            <div class="explorelocationimg">
                <img src="images/img10.jpg" alt="" />
                <div class="exploreheading">China</div>
            </div>
            </div>
        </div>
        <div class="col-xl-3 col-md-4 col-sm-6 col-12 pl-2 pr-2 mb-4 wow fadeInDown">
            <div class="explorelocationbox">
            <div class="explorelocationimg">
                <img src="images/img11.jpg" alt="" />
                <div class="exploreheading">Australia</div>
            </div>
            </div>
        </div>
        <div class="col-xl-3 col-md-4 col-sm-6 col-12 pl-2 pr-2 mb-4 wow fadeInDown">
            <div class="explorelocationbox">
            <div class="explorelocationimg">
                <img src="images/img12.jpg" alt="" />
                <div class="exploreheading">France</div>
            </div>
            </div>
        </div>
        </div>
    </div>
    </section>

    <section class="aboutcontainer">
    <div class="aboutcontainerinner">
        <div class="container">
        <div class="row justify-content-end">
            <div class="col-xl-5 col-md-7 col-sm-12 col-12 wow fadeInDown">
            <div class="aboutcontent">
                <h2>About G9X</h2>
                <h5>Your Digital Guru For Buy/ Sell</h5>
                <p><?php echo html_entity_decode($about->short_description[app()->getLocale()] ); ?></p>
                
                <a href="javascript:void(0);" class="viewallbtn"><span>view all</span><i class="icon icon-arrow-thin-right"></i></a>
            </div>
            </div>
        </div>
        </div>
    </div>
    </section>


    <section class="downloadappcontainer">
    <div class="container">
        <div class="row">
        <div class="col-xl-6 col-md-6 col-sm-6 col-12 align-self-center wow fadeInDown">
            <div class="mobileappbx">
            <h2>Download this app</h2>
            <h5>Consectetur adipiscing elit, sed do eiu</h5>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiu smod tempor incididunt ut labore et dolore magna aliqua. Quis ipsum suspendisse ultrices gravida. Risus commodo.</p>
            <a href="<?php echo e($settings->app_store); ?>" target="_blank" class="appbtn"><img src="images/apple-store.png" alt="Apple Store"></a>
            <a href="<?php echo e($settings->google_store); ?>" target="_blank" class="appbtn"><img src="images/android-store.png" alt="Android Store"></a>
            </div>
        </div>

        <div class="col-xl-6 col-md-6 col-sm-6 col-12 align-self-end wow fadeInUp">
            <div class="mobileappimg">
            <span><img src="images/mobile-app-img.png" alt="" /></span>
            </div>
        </div>

        </div>
    </div>
    </section>
    <?php $__env->stopSection(); ?>


    
<?php echo $__env->make('layout.default', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>