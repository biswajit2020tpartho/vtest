<!-- Required meta tags -->
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<meta name="description" content="">
<meta name="keywords" content="">
<meta name="author" content="">
<meta name="theme-color" content="#fff" />
<link rel="icon" type="image/ico" sizes="32x32" href="images/favicon.ico">
<title>GX9 :: Your digital guru for buy and sell</title>

<!-- Google Fonts -->
<link href="https://fonts.googleapis.com/css?family=Montserrat:300,400,500,600,700,800,900&display=swap" rel="stylesheet" />
<!-- flag -->
<link href="https://cdnjs.cloudflare.com/ajax/libs/flag-icon-css/3.1.0/css/flag-icon.min.css" rel="stylesheet">
<!-- Bootstrap CSS -->
<?php echo Html::style( asset('css/bootstrap.min.css')); ?>

<!-- FontAwesome -->
<link href="fonts/font-awesome/css/font-awesome.min.css" rel="stylesheet" />
<!-- Owl Carousel -->
<?php echo Html::style( asset('css/owl.carousel.min.css')); ?>

<?php echo Html::style( asset('css/owl.theme.default.min.css')); ?>

<?php echo Html::style( asset('css/animations.css')); ?>

<!-- CustomCss -->
<?php echo Html::style( asset('css/style.css')); ?>

<?php echo Html::style( asset('css/media.css')); ?>

