<?php $__env->startSection('content'); ?>

    <div>
        <p><a title="Return" href="<?php echo e($_GET['return_url']); ?>"><i class="fa fa-chevron-circle-left "></i>
            &nbsp; Back To <?php echo e(CRUDBooster::getCurrentModule()->name); ?> Listing</a>
        </p>
        <div class="panel panel-default">
            <div class="panel-heading">
                <strong><i class="fa fa-flag-o"></i> <?php echo e($page_title); ?></strong>
            </div>
            <div class="panel-body" style="padding:20px 0px 0px 0px">
                <div class="box-body" id="parent-form-area">
                    <div class="table-responsive">
                        <table id="table-detail" class="table table-striped">
                            <tbody>

                                <?php $__currentLoopData = $details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if(!empty($data['data'])): ?>
                                        <tr>
                                            <td>
                                                <?php echo e($data['field_name']); ?>

                                            </td>
                                            <?php if($data['field_name'] == 'Image'): ?>
                                                <td>
                                                    <a data-lightbox='roadtrip' href='<?php echo e(asset($data["data"])); ?>'>
                                                        <img style='max-width:150px' title="Image For Banner Image" src='<?php echo e(asset($data["data"])); ?>'/>
                                                    </a>
                                                </td>
                                            <?php else: ?>
                                                <td>
                                                    <?php echo $data['data']; ?>

                                                </td>
                                            <?php endif; ?>
                                        </tr>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                <!-- /.box-body -->
                <div class="box-footer" style="background: #F5F5F5">
                    <div class="form-group">
                        <label class="control-label col-sm-2"></label>
                        <div class="col-sm-10">
                        </div>
                    </div>
                </div>
                <!-- /.box-footer-->
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('crudbooster::admin_template', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>