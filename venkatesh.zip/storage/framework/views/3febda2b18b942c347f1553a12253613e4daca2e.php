<div class="navigationinner">
    <div class="container">
      <div class="row">
        <div class="col-12">
          <div class="navigation">
            <div class="navigationbox">
              <div class="navuser">
                <div class="userimg">
                  <img src="images/logo-icon.png" alt="Logo">
                </div>
                <h3>GX9</h3>
                <p>Your digital guru for buy / sell</p>
              </div>
              <ul class="sf-menu">
                <li class="active"><a href="<?php echo e(url('/')); ?>">Home</a></li>
                <?php $__currentLoopData = $data['navMenu']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><a href="<?php echo e(url(app()->getLocale().'/all-ads')); ?>/<?php echo e($menu->getPageslug->slug); ?>"><?php echo e($menu->name); ?></a></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>