    

    <?php $__env->startSection('content'); ?>

    <div class="dashboard">
	  <div class="dashboardcontainer">
	    <div class="afterloginnavigation">
	      <div class="usercolumn">
	        <div class="userimg">
	        <?php if($userDetails->photo): ?>
	          <img src="<?php echo e(url('/')); ?>/<?php echo e($userDetails->photo); ?>" alt="User Image">
	        <?php else: ?>
	          <img src="<?php echo e(url('/')); ?>/images/user-noimage.jpg" alt="User Image">
	        <?php endif; ?>
	        </div>
	        <h3><?php echo e($userDetails->name); ?></h3>
	        <!-- <p>Visual artist</p> -->
	      </div>
	      <div class="usernavlist">
	         <?php echo $__env->make('layout.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?> 
	      </div>
	    </div>
	    <div class="layoutcontainer">
	      <div class="layoutcontent">
	        <div class="layoutcontentinner">
	          <div class="afterrightbox">
		          <a class="profilebtn" href="javascript:void(0);"><i class="icon icon-user"></i><span>Profile Nav</span></a>
		          <h3>Dashboard / packages</h3>
		          <div class="purchagepagebox">
		          	 <?php if(Session::has('error_message')): ?>
              <div class="alert <?php echo e(Session::get('alert-class', 'alert-danger alert-dismissible')); ?>"><?php echo e(Session::get('error_message')); ?><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button></div>
              <?php endif; ?> 
              <?php if(Session::has('success_message')): ?>
              <div class="alert <?php echo e(Session::get('alert-class', 'alert-success alert-dismissible')); ?>"><?php echo e(Session::get('success_message')); ?><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button></div>
              <?php endif; ?> 
			        <div class="row ml-n1 mr-n1">
			        	<?php if($packagedetails): ?>
				        	<?php $__currentLoopData = $packagedetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $package): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			                <div class="col-xl-4 col-lg-6 col-md-12 col-sm-12 col-12 pl-1 pr-1 mb-3">
			                  <div class="membershipbox <?php if($currentPackage==$package->id): ?> active <?php endif; ?>">
			                    <div class="mtopheading"><?php echo e($package->title[app()->getLocale()]); ?></div>
			                    <div class="mprice"><i class="fa fa-euro"></i><?php echo e($package->price); ?><span>/ <?php echo e($package->expires_in_months); ?> Month</span></div>
			                    <div class="mtopheading">Credit Points : <?php echo e($package->credit_point); ?></div>
			                    <?php echo html_entity_decode($package->description[app()->getLocale()]); ?>

			                    <button class="selectbtn packageDetails" type="button" id="<?php echo e($package->id); ?>">Select</button>
			                  </div>
			                </div>	
			                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		                <?php else: ?>
		                	<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 pl-1 pr-1 mb-3">No Package Found!</div>
		                <?php endif; ?>     

	              	</div>
	              	<div class="col-12">
	                  <div class="spinnerbx">
	                    <?php echo e($packagedetails->links()); ?>

	                  </div>
	                </div>
	            </div>
		        </div>
	        </div>
	      </div>
	    </div>
	  </div>
	</div>

	<!-----------------------Modal Package------------------------>
	<div class="modal fade exviewdetailsmodal" id="packageModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
	  <div class="modal-dialog modal-dialog-centered" role="document">
	    <div class="modal-content">
	      <div class="modal-header">
	        <h5 class="modal-title" id="exampleModalLongTitle">Package Details</h5>
	        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
	          <span aria-hidden="true">&times;</span>
	        </button>
	      </div>
	      <form method="POST" action="<?php echo e(url('en/create-payment')); ?>">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="amount" value="" id="amount">
            <input type="hidden" name="item_id" value="" id="item_id">
	      <div class="modal-body">	      	
	      	<div class="purchagepagebox">
			    <div class="row ml-n1 mr-n1">			       	
	              <div class="membershipbox">
	                <div class="mtopheading" id="pck_name"></div>
	                <div class="mprice" id="pck_price"></div>
	                <div class="mtopheading" id="pck_crept"></div>
	                <div id="pck_description"></div>	         
	              </div>		            
            	</div>
            </div>         
	      </div>
	      <div class="modal-footer">
	        <button class="btn btn-secondary" type="submit" id="<?php echo e($package->id); ?>">Buy Now</button>
	      </div>
	    </form>
	    </div>
	  </div>
	</div>

    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.default', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>