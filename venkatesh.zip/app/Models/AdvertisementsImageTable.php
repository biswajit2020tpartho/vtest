<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class AdvertisementsImageTable extends Model
{
	protected $table = 'advertisements_image_table';
    //
}
