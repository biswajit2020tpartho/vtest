<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class AdvertisementReviw extends Model
{
    //relations
}
