<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class AdvertisementAmentie extends Model
{
    public function getAmenties(){
        return $this->belongsTo(Amentie::class, 'amenties_id');
    }
}
