<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Inquiry extends Model
{
    protected $table = 'inquiry_table';
    // protected $fillable = [
    //     "name",
    //     "email",
    //     "message"
    // ];
    protected $guarded = [];
}
