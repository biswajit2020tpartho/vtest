<?php

namespace App\Providers;
use Illuminate\Support\Facades\View;

use Illuminate\Support\ServiceProvider;
use App\Models\Social;
use App\Models\Setting;
use App\Models\Categorie;
use App\Models\Page;
use App\Models\SeoUrl;
use App\Models\User;
use Session;
class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {
        //
    }

    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot()
    {
        // Set the app locale according to the URL
        app()->setLocale(request()->segment(1));
        $curr_lang = request()->segment(1);
        View::composer(['layout.header','layout.footer','layout.nav'], function ($view) {
            $data = array();
            $data['socialMedia']=   Social::where('status',1)->get();
            $data['navMenu']    =   Categorie::where('is_menu',1)->get();
            $data['settings']   =   Setting::find(1);
            $data['curr_lang']  =   request()->segment(1);
            $data['footer_menu']     = Page::where('status',1)->where('is_menu','1')->where('id','<>','2')->get();      
            if(session()->get('userexist')!=""){
                $data['userDetails'] = User::where([['email','=',session()->get('userexist')],['status','=','Active']])->first();
            }   
            //dd( $data['userDetails']);
            $view->with('data',$data); // bind data to view
        });
    }
}
