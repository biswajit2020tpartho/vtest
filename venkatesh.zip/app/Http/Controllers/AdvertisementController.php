<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Advertisement;
use App\Models\AdvertisementsImageTable;
use App\Models\AdvertisementReviw;
use App\Models\User;
use App\Models\AdvertisementAmentie;
use App\Models\Amentie;
use App\Models\Wishlist;
use App\Models\SeoUrl;
use App\Models\Categorie;
use App\Models\AdvertisementInquirie;
use View;
use Datatables;
use Validator;
class AdvertisementController extends Controller
{
    public function index($slug=""){
    	$data	= array();
        if (isset($_REQUEST['sort'])) {
            $filter = $_REQUEST['sort'];
        } else {
            $filter = 'title';
        }

        if (isset($_REQUEST['order'])) {
            $order = $_REQUEST['order'];
        } else {
            $order = 'ASC';
        }

        $data['catList'] = Categorie::where('status','1')->with(['getCategorywiseAds'=>function($q){$q->where('status',1)->where('approved',1);
        }])->get();

        if($slug ==""){
            $data['allAdsList'] = Advertisement::where('status','1')
            ->where('approved','1')
            ->orderBy($filter,$order)
            ->paginate(6);
        }else{
            $data['categoryDetails'] = SeoUrl::where('slug',$slug)->first();
            $data['cat_id']     = $data['categoryDetails']->resource->id;
            $data['allAdsList'] = Advertisement::where('status','1')
                ->where('approved','1')
                ->where('cat_id',$data['cat_id'])
                ->orderBy($filter,$order)
                ->paginate(6);
        }
    	return View::make('all_ads')->with($data);
    }

    public function ads_details($slug){
    	$data	= array();
        $data['pagedetails'] = SeoUrl::where('slug',$slug)->first();
        $id = $data['pagedetails']->resource->id;
    	$data['adsdetails'] = Advertisement::where('status','1')->where('id',$id)->first();
    	$data['adsImages'] = AdvertisementsImageTable::where('status','1')->where('ads_id',$id)->get();
    	$data['sellerDetails'] = User::where('status','1')->first();
        $data['review'] = AdvertisementReviw::where('status','1')->where('ads_id',$id)->count();
        $data['rating'] = round(AdvertisementReviw::where('status','1')->where('ads_id',$id)->avg('rating'));
        $data['adsAmenties'] = AdvertisementAmentie::where('status','1')->where('ads_id',$id)->get();
        if(session()->get('userexist')!=""){
            $userDetails = User::where([['email','=',session()->get('userexist')],['status','=','Active']])->first();
            $user_id = (int)$userDetails->id;
        }else{
            $user_id = 0;
        }

        $data['wishlist'] = Wishlist::where('ads_id',$id)->where('user_id',$user_id)->first();

    	//dd($data['wishlist']);
    	return View::make('ads_details')->with($data);

    }

    public function write(Request $request){
        $json = array();       
        $adsId = $request->input('ads_id');
        $name = $request->input('name');
        $message = $request->input('text');
        $rating = $request->input('rating');
        if ($name == "") {
            $json['error'] = "Please enter your name!";
        }
        if ($message == "") {
            $json['error'] = "Please enter your review!";
        }
        if ($rating == "") {
            $json['error'] = "Please select your rating!";
        }
        if (!isset($json['error'])) {            
            $reviw = new AdvertisementReviw;
            $reviw->ads_id      = $adsId;
            $reviw->user_id     = 0;
            $reviw->name        = $name;
            $reviw->rating      = $rating;
            $reviw->review_text = $message;
            $reviw->save();           
            $json['success'] = "Success,Thanks for your review.";
        }
        return json_encode($json);
        
    }

    public function add_post(){
        $data = array();
        $data['userDetails'] = User::where([['email','=',session()->get('userexist')],['status','=','Active']])->first();
        return View::make('add_post')->with($data);
    }

    public function view_inquiries(){        
        $data = array();
        $data['userDetails'] = User::where([['email','=',session()->get('userexist')],['status','=','Active']])->first();
        $data['inqueryDetails'] = AdvertisementInquirie::where('user_id',$data['userDetails']->id)->paginate(10);
        if(request()->ajax())
        {  

            return datatables()->of(AdvertisementInquirie::latest()->get())
                    ->addColumn('action', function($data){
                        $button = '<button type="button" name="edit" id="'.$data->id.'" class="view btn btn-primary btn-sm">View</button>';                
                        return $button;
                    })
                    ->editColumn('id', '{{$id}}')
                    ->rawColumns(['action'])
                    ->make(true);
        }
        return view::make('view_inquiries')->with($data);
    }

    public function getInquiriesData(){        
        if(request()->ajax())
        {
            // $data['userDetails'] = User::where([['email','=',session()->get('userexist')],['status','=','Active']])->first();
            // $data['inqueryDetails'] = AdvertisementInquirie::where('user_id',$data['userDetails']->id)->get();

            return datatables()->of(AdvertisementInquirie::latest()->get())
                    ->addColumn('action', function($data){
                        $button = '<button type="button" name="edit" id="'.$data->id.'" class="edit btn btn-primary btn-sm">View</button>';                
                        return $button;
                    })
                    ->rawColumns(['action'])
                    ->make(true);
        }
        return view('view_inquiries');
    }

    public function inquery_data($id){
        if(request()->ajax())
        {
            $data = AdvertisementInquirie::findOrFail($id);
            return response()->json(['data' => $data]);
        }
    }

    public function adsInquery(Request $request){
        $json = array();       
        $adsId = $request->input('ads_id');
        $seller_id = $request->input('seller_id');
        $name = $request->input('name');
        $email = $request->input('email');
        $phone_no = $request->input('phone_no');
        $message = $request->input('message');

        $rules = array(
            'name'      =>  'required',
            'email'     =>  'required|email',
            'phone_no'  =>  'required|numeric|digits:10',
            'message'   =>  'required',            
        );
        $error = \Validator::make($request->all(), $rules);
        if($error->fails())
        {
            return response()->json(['errors' => $error->errors()->all()]);
        }                   
        $inquirie = new AdvertisementInquirie;
        $inquirie->ads_id      = $adsId;
        $inquirie->user_id     = $seller_id;
        $inquirie->name        = $name;
        $inquirie->email       = $email;
        $inquirie->phone_no    = $phone_no;
        $inquirie->message     = $message;
        $inquirie->save();        
        return response()->json(['success' => 'Success,Message successfully submitted']);        
    }

}
