<?php


namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Auth;
use App\Models\Banner;
use App\Models\Categorie;
use App\Models\Advertisement;
use App\Models\AdvertisementReviw;
use App\Models\Country;
use App\Models\State;
use App\Models\HowitWork;
use App\Models\Page;
use App\Models\Setting;
use App\Models\Inquiry;
use App\Models\SeoUrl;
use App\Models\User;
use DB;
use Session;
use App;
use View;
use Redirect;
class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    // public function __construct()
    // {
    //     $this->middleware('auth');
    // }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {

        $data['getBanner']       = Banner::where('page_id',2)->where('status',1)->get();    
        $data['featureCategory'] = Categorie::where('is_feature',1)->where('status',1)->get(); 
        if(session()->get('userexist')!=""){
            $userDetails = User::where([['email','=',session()->get('userexist')],['status','=','Active']])->first();
            $user_id = (int)$userDetails->id;
        }else{
            $user_id = 0;
        }

        $data['advertisement'] = Advertisement::where('approved',1)->where('status',1)->where('is_featured',1)->with(['getAdvtwishlist'=>function($q) use ($user_id){$q->where('user_id','=',$user_id);
        }])->get()->take(8);


        $data['howit_works']      = HowitWork::get();
        $data['about']           = Page::where('id',1)->find(1);

        $data['settings']        = Setting::find(1);
        $data['categorie']       = Categorie::where('status',1)->get();
        
        //$review = $data['advertisement'][1]->getAdvtStates;
        // dd($review );
         //dd($data['about']->short_description['en']);
      
        return View::make('home')->with($data);
    }
    public function submitInquiry(Request $request){
        $json = array();       
        $name = $request->input('name');
        $email = $request->input('email');
        $message = $request->input('message');
        
        if ($name == "") {
            $json['error'] = "Please enter name";
        }

        if ($email == "") {
            $json['error'] = "Please enter valid email!";
        }

        if ($message == "") {
            $json['error'] = "Please enter your message!";
        }
        if (!isset($json['error'])) {
            $data=array('name'=>$name,
                "email"=>$email,
                "message"=>$message,
                "created_at" =>  date('Y-m-d H:i:s'),
            );
            $Inquiry = new Inquiry;
            $Inquiry->name      = $name;
            $Inquiry->email     = $email;
            $Inquiry->message   = $message;
            $Inquiry->save();
            //DB::table('inquiry_table')->insert($data);
            $json['success'] = "Success,Thanks for your feedback.";
        }

        
        return json_encode($json);
    }
    
    public function getSignOut() {        
        Auth::logout();
        return Redirect::route('home');    
    }

    function thank_you($slug=NULL)
    { 
        if($slug == 'success'){
            $data['msg']= 'Success.Your query has been successfully submited.We will contact you soon.';
        }else{
            $data['msg']= 'Thank you.Your registration process has been completed successfully';
        }
        return View::make('thankyou')->with($data);      
    }


}
