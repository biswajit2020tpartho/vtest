<?php 
namespace App\Http\Traits;

use DB;
use Mail;
use CRUDBooster;
trait EmailSetupTrait {
    public function initiateMailSingle($config = []){
    	//dd($config);
    	if(!empty($config)){

    		if($config['email_for']=='FOM')
    		{
	    		$data=array();

				$email_data = array(
	            'from_name'         =>  $config['from']['name'],
	            'to_name'           =>  $config['mail_key_code']['recievername'],               
	            'email_id'          =>  $config['to'],
	            'site_email'        =>  $config['from']['email'],
	            'login_email'	=>	$config['mail_key_code']['login_email'],
	            'login_password'	=>	$config['mail_key_code']['login_password'],
	            'logo' 				=>	$config['mail_key_code']['logo'],
	            'description'		=>	$config['mail_key_code']['message'],
	            'subject'			=> 	$config['subject']

	            
	            );
	            //$email_data = $config['mail_key_code'];
	            //dd($email_data);

	             Mail::send($config['email_slug_name'], $email_data,  function ($message) use ($email_data) 
	                {
	                $message->from($email_data['site_email'], $email_data['from_name']);
	                $message->to($email_data['email_id'] )->subject($email_data['subject']);            
	            });

    		}
    		elseif($config['email_for']=='SOM')
    		{
	    		$data=array();

				$email_data = array(
	            'from_name'         =>  $config['from']['name'],
	            'to_name'           =>  $config['mail_key_code']['recievername'],               
	            'email_id'          =>  $config['to'],
	            'site_email'        =>  $config['from']['email'],
	            'login_email'	=>	$config['mail_key_code']['login_email'],
	            'login_password'	=>	$config['mail_key_code']['login_password'],
	            'logo' 				=>	$config['mail_key_code']['logo'],
	            'description'		=>	$config['mail_key_code']['message'],
	            'subject'			=> 	$config['subject']

	            
	            );
	            //$email_data = $config['mail_key_code'];
	            //dd($email_data);

	             Mail::send($config['email_slug_name'], $email_data,  function ($message) use ($email_data) 
	                {
	                $message->from($email_data['site_email'], $email_data['from_name']);
	                $message->to($email_data['email_id'] )->subject($email_data['subject']);            
	            });

    		}
    			elseif($config['email_for']=='order')
    		{
    		    //dd($config);
    		    
	    		$data=array();

				$email_data = array(
	            'from_name'         =>  $config['from']['name'],
	            'to_name'           =>  $config['mail_key_code']['recievername'],               
	            'email_id'          =>  $config['to'],
	            'site_email'        =>  $config['from']['email'],
	            'logo' 				=>	$config['mail_key_code']['logo'],
	            'description'		=>	$config['mail_key_code']['message'],
	            'subject'			=> 	$config['subject']

	            
	            );
	            //$email_data = $config['mail_key_code'];
	           // dd($email_data);

	             Mail::send($config['email_slug_name'], $email_data,  function ($message) use ($email_data) 
	                {
	                $message->from($email_data['site_email'], $email_data['from_name']);
	                $message->to($email_data['email_id'] )->subject($email_data['subject']);            
	            });

    		}
    		
    			elseif($config['email_for']=='paymentsuccess')
    		{
    		    //dd($config);
    		    
	    		$data=array();

				$email_data = array(
	            'from_name'         =>  $config['from']['name'],
	            'to_name'           =>  $config['mail_key_code']['recievername'],               
	            'email_id'          =>  $config['to'],
	            'site_email'        =>  $config['from']['email'],
	            'logo' 				=>	$config['mail_key_code']['logo'],
	            'description'		=>	$config['mail_key_code']['message'],
	            'subject'			=> 	$config['subject'],
	            'file_path'			=> 	$config['mail_key_code']['attachment']

	            
	            );
	            //$email_data = $config['mail_key_code'];
	           // dd($email_data);

	             Mail::send($config['email_slug_name'], $email_data,  function ($message) use ($email_data) 
	                {
	                $message->from($email_data['site_email'], $email_data['from_name']);
	                $message->to($email_data['email_id'] )->subject($email_data['subject']); 
	                $message->attach($email_data['file_path'], $options = []);
	            });

    		}
    		
    			elseif($config['email_for']=='contact')
    		{
    		    //dd($config);
    		    
	    		$data=array();

				$email_data = array(
	            'from_name'         =>  $config['from']['name'],
	            'to_name'           =>  $config['mail_key_code']['recievername'],               
	            'email_id'          =>  $config['to'],
	            'site_email'        =>  $config['from']['email'],
	            'logo' 				=>	$config['mail_key_code']['logo'],
	            'description'		=>	$config['mail_key_code']['message'],
	            'subject'			=> 	$config['subject'],
	          

	            
	            );
	            //$email_data = $config['mail_key_code'];
	           // dd($email_data);

	             Mail::send($config['email_slug_name'], $email_data,  function ($message) use ($email_data) 
	                {
	                $message->from($email_data['site_email'], $email_data['from_name']);
	                $message->to($email_data['email_id'] )->subject($email_data['subject']); 
	                
	            });

    		}
    		
    			elseif($config['email_for']=='contactadmin')
    		{
    		    //dd($config);
    		    
	    		$data=array();

				$email_data = array(
	            'from_name'         =>  $config['from']['name'],
	            'to_name'           =>  $config['mail_key_code']['recievername'],               
	            'email_id'          =>  $config['to'],
	            'site_email'        =>  $config['from']['email'],
	            'logo' 				=>	$config['mail_key_code']['logo'],
	            'description'		=>	$config['mail_key_code']['message'],
	            'subject'			=> 	$config['subject'],
	            'contact_no'        =>  $config['mail_key_code']['mobileno'],
	            'enquiry'        =>  $config['mail_key_code']['enquiry'],
	          

	            
	            );
	            //$email_data = $config['mail_key_code'];
	           // dd($email_data);

	             Mail::send($config['email_slug_name'], $email_data,  function ($message) use ($email_data) 
	                {
	                $message->from($email_data['site_email'], $email_data['from_name']);
	                $message->to($email_data['email_id'] )->subject($email_data['subject']); 
	                
	            });

    		}
    		
    			elseif($config['email_for']=='forgotpwd')
    		{
    		    //dd($config);
    		    
	    		$data=array();

				$email_data = array(
	            'from_name'         =>  $config['from']['name'],
	            'to_name'           =>  $config['mail_key_code']['recievername'],               
	            'email_id'          =>  $config['to'],
	            'site_email'        =>  $config['from']['email'],
	            'logo' 				=>	$config['mail_key_code']['logo'],
	            'description'		=>	$config['mail_key_code']['message'],
	            'subject'			=> 	$config['subject'],
	            'password'        =>  $config['mail_key_code']['password'],
	          
	          

	            
	            );
	            //$email_data = $config['mail_key_code'];
	           // dd($email_data);

	             Mail::send($config['email_slug_name'], $email_data,  function ($message) use ($email_data) 
	                {
	                $message->from($email_data['site_email'], $email_data['from_name']);
	                $message->to($email_data['email_id'] )->subject($email_data['subject']); 
	                
	            });
	            return 1;

    		}
    		
    			elseif($config['email_for']=='user-registration')
    		{
	    		$data=array();

				$email_data = array(
	            'from_name'         =>  $config['from']['name'],
	            'to_name'           =>  $config['mail_key_code']['recievername'],               
	            'email_id'          =>  $config['to'],
	            'site_email'        =>  $config['from']['email'],
	            'login_email'	=>	$config['mail_key_code']['login_email'],
	            'login_password'	=>	$config['mail_key_code']['login_password'],
	            'logo' 				=>	$config['mail_key_code']['logo'],
	            'description'		=>	$config['mail_key_code']['message'],
	            'subject'			=> 	$config['subject']

	            
	            );
	            

	             Mail::send($config['email_slug_name'], $email_data,  function ($message) use ($email_data) 
	                {
	                $message->from($email_data['site_email'], $email_data['from_name']);
	                $message->to($email_data['email_id'] )->subject($email_data['subject']);            
	            });

    		}
    		
    		else
    		{
		    			$data=array();

					/*$email_data = array(
		            'name'              =>  'User',               
		            'email_id'          =>  $email,
		            'site_email'        =>  $site_email

		            
		            );*/
		            $email_data = $config['mail_key_code'];
		            //dd($email_data);

		             Mail::send($config['email_slug_name'], $email_data,  function ($message) use ($email_data) 
		                {
		                $message->from($email_data['senderemail'], $email_data['appname']);
		                $message->to($email_data['recieveremail'] )->subject($config['subject']);            
		            });

    		}


			

			
			
    	}else{
    		return response()->json('unable to send mail',401);
    	}        
    }
}