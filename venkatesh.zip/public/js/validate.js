$(document).ready(function(){
	$("#login_form").validate({
		rules: {
			password_log: {
				required: true,
				minlength: 5
			},
			email_id_log: {
				required: true,
				email: true
			},
		},
		messages: {			
			email_id_log: {
				required: "Please enter a email address",
				email: "Please enter a valid email address"
			},
			password_log: {
				required: "Please provide a password",
				minlength: "Your password must be at least 5 characters long"
			}
		}
	});

	$("#registration_form").validate({
		rules: {
			user_name: {
				required: true,
				minlength: 3
			},
			phone_number: {
				required: true,
				number: true,
				maxlength:10,
				minlength:10
			},
			email:{
				required:true,
				email:true
			},
			user_password:{
				required:true,
				minlength:5
			},
			//agree:"required"
		},
		messages: {			
			phone_number: {
				required: "Please enter a number",
				maxlength: "Please enter a only 10 digits",
				minlength: "Please enter a only 10 digits"
			},
			user_name: {
				required: "Please enter a user name",
				minlength: "Your user name must be at least 3 characters long"
			},
			email:{
				required: "Please enter a email address",
				email: "Please enter a valid email address"
			},
			user_password: {
				required: "Please provide a password",
				minlength: "Your password must be at least 5 characters long"
			},
			agree:"Please select terms and conditions"
		}
	});

	$("#forgot_password_form").validate({
		rules: {
			email_id_forgot:{
				required:true,
				email:true
			}
		},
		messages: {			
			email_id_forgot:{
				required: "Please enter a email address",
				email: "Please enter a valid email address"
			}
		}
	});
	$("#contact_form").validate({
		rules:{
			first_name:"required",
			last_name :"required",
			phone_nos: {
				required: true,
				number: true,
				maxlength:10,
				minlength:10
			},
			email:{
				required:true,
				email:true
			},
			message:"required",
		},
		messages:{
			first_name:"Please enter your first name!",
			last_name :"Please enter your lase name!",
			phone_nos: {
				required: "Please enter a number!",
				maxlength: "Please enter a only 10 digits!",
				minlength: "Please enter a only 10 digits!"
			},
			email:{
				required: "Please enter your email address!",
				email: "Please enter your valid email address!"
			},
			message:"Please enter your message!"
		}
	});
});	
