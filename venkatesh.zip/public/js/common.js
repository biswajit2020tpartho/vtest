$(document).ajaxStart(function(){
  // Show image container
  $("#loader").show();
});
$(document).ajaxComplete(function(){
  // Hide image container
  $("#loader").hide();
});

function submitInquiry(){
	$.ajax({
		url: 'http://localhost/venkatesh/public/submitInquiry',
		type: 'post',
		dataType: 'json',
		data: $("#form-review").serialize(),
		beforeSend: function() {
			$('#button-review').button('loading');
		},
		complete: function() {
			$('#button-review').button('reset');
		},
		success: function(json) {
			$('.alert-dismissible').remove();

			if (json['error']) {
				console.log("error");
				$('#review').after('<div class="alert alert-danger alert-dismissible"><i class="fa fa-exclamation-circle"></i> ' + json['error'] + '</div>');
			}

			if (json['success']) {
				$('#review').after('<div class="alert alert-success alert-dismissible"><i class="fa fa-check-circle"></i> ' + json['success'] + '</div>');

				$('input[name=\'name\']').val('');
				$('input[name=\'email\']').val('');
				$('input[name=\'message\']').val('');
				
			}
		}
	});
}

$('#button-review').on('click', function() {
	$.ajax({
		url: 'http://localhost/venkatesh/public/adsReview',
		type: 'post',
		dataType: 'json',
		data: $("#form-review").serialize(),
		beforeSend: function() {
			$('#button-review').button('loading');
		},
		complete: function() {
			$('#button-review').button('reset');
		},
		success: function(json) {
			$('.alert-dismissible').remove();

			if (json['error']) {
				$('#review').after('<div class="alert alert-danger alert-dismissible"><i class="fa fa-exclamation-circle"></i> ' + json['error'] + '</div>');
			}

			if (json['success']) {
				$('#review').after('<div class="alert alert-success alert-dismissible"><i class="fa fa-check-circle"></i> ' + json['success'] + '</div>');

				$('input[name=\'name\']').val('');
				$('textarea[name=\'text\']').val('');
				$('input[name=\'rating\']:checked').prop('checked', false);
			}
		}
	});
});

$('#inquery_button').on('click', function() {
	$.ajax({
		url: 'http://localhost/venkatesh/public/adsInquery',
		type: 'post',
		dataType: 'json',
		data: $("#inquery_form").serialize(),
		beforeSend: function() {
			$('#button-review').button('loading');
		},
		complete: function() {
			$('#button-review').button('reset');
		},
		success: function(data) {
			var html = '';
		    if(data.errors)
		    {
		    	// <div class="alert alert-danger alert-dismissible"><i class="fa fa-exclamation-circle"></i> ' + json['error'] + '</div>

		      html = '<div class="alert alert-danger alert-dismissible">';
		      for(var count = 0; count < data.errors.length; count++)
		      {
		       html += '<p>' + data.errors[count] + '</p>';
		      }
		      html += '</div>';
		    }
		    if(data.success)
		    {
		      html = '<div class="alert alert-success">' + data.success + '</div>';	
		      $('input[name=\'name\']').val('');
		      $('input[name=\'email\']').val('');
		      $('input[name=\'phone_no\']').val('');
		      $('input[name=\'message\']').val('');
			  $('textarea[name=\'text\']').val('');
			  $('input[name=\'rating\']:checked').prop('checked', false);      
		    }
		    $('#form_result').html(html);
		}
	});
});

$("#forgot_pwd").click(function(){
  $("#forgot_password_form").css('display','block');
  $("#login_form").css('display','none');
  //$("#current").text('Forgot Password');  
});
$("#sign_in").click(function(){
  $("#forgot_password_form").css('display','none');
  $("#login_form").css('display','block');
  // $("#current").text('Sign In');
});


// Product List
$('#list-view').click(function() {
	// $('#content .product-grid > .clearfix').remove();
	$('.probxsec .row > .product-list').attr('class', 'product-list col-xl-12 col-md-12 col-sm-12 col-12 colproject');
	$('#grid-view').removeClass('active');
	$('#list-view').addClass('active');
	localStorage.setItem('display', 'list');
});

// Product Grid
$('#grid-view').click(function() {
	$('.probxsec .row > .product-list').attr('class', 'product-list col-xl-4 col-md-4 col-sm-6 col-12 colproject');
	$('#list-view').removeClass('active');
	$('#grid-view').addClass('active');
	localStorage.setItem('display', 'grid');
});

if (localStorage.getItem('display') == 'list') {
	$('#list-view').trigger('click');
	$('#list-view').addClass('active');
} else {
	$('#grid-view').trigger('click');
	$('#grid-view').addClass('active');
}

$(document).ready(function() {
 	// $('#inquery_list').DataTable({
  // 	processing: true,
  // 	serverSide: true,
  // 	ajax:{
  //  		url: "http://localhost/venkatesh/public/en/view-inquiries",   		
  // 	},
  // 	columns:[
		// { data: 'id',	name: 'id'},
		// { data: 'name',	name: 'name'},
		// { data: 'email', name: 'email'},
		// { data: 'phone_no', name: 'phone_no'},
		// { data: 'message',name: 'message'},
		// { data: 'action',name: 'action'}
  // 	]
 	// });

 	$('#inquery_list').DataTable();
});

$(document).on('click', '.view', function(){
	var id = $(this).attr('id');
	$.ajax({
		url: 'http://localhost/venkatesh/public/inquery_data/'+id,
		headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},
		type: 'get',
		dataType: 'json',
		success: function(html) {
			$('#name').html(html.data.name);
			$('#email').html(html.data.email);
			$('#phone_no').html(html.data.phone_no);
			$('#message').html(html.data.message);				
			$('#exampleModalCenter').modal('show');
		}
	});
	
});

var wishlist = {
	'add': function(product_id) {
		$.ajax({
			url: 'http://localhost/venkatesh/public/wishlist-add',
			headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},
			type: 'post',
			data: 'ads_id=' + product_id,
			dataType: 'json',
			success: function(json) {				
				$('.alert-dismissible').remove();

				if (json['redirect']) {
					location = json['redirect'];
				}

				if (json['success']) {
					$('#content').parent().before('<div class="alert alert-success alert-dismissible"><i class="fa fa-check-circle"></i> ' + json['success'] + ' <button type="button" class="close" data-dismiss="alert">&times;</button></div>');
					if(json['is_exists'] == "1"){
						$('.sharerightb #wishlist > i').attr('class', 'fa fa-heart');
						$("#heartbx_"+product_id).html('<a href="javascript:void(0);" onclick="wishlist.add('+product_id+');"><i class="fa fa-heart"></i></a>');
					}else{
						$('.sharerightb #wishlist > i').attr('class', 'fa fa-heart-o');
						$("#heartbx_"+product_id).html('<a href="javascript:void(0);" onclick="wishlist.add('+product_id+');"><i class="fa fa-heart-o"></i></a>');
					}					
					alertify.alert(json['success']).set('basic', true); 
				}

				$('#wishlist-total span').html(json['total']);
				$('#wishlist-total').attr('title', json['total']);

				$('html, body').animate({ scrollTop: 0 }, 'slow');
			},
			error: function(xhr, ajaxOptions, thrownError) {
				alert(thrownError + "\r\n" + xhr.statusText + "\r\n" + xhr.responseText);
			}
		});
	},
	'remove': function() {

	}
}

$(document).on('click', '.packageDetails', function(){
	var id = $(this).attr('id');
	var lang = $('meta[name="lang"]').attr('content');
	$.ajax({
		url: 'http://localhost/venkatesh/public/package_details/'+id,
		headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},
		type: 'get',
		dataType: 'json',
		success:function(html){
			$("#amount").val(html.data.price);
			$("#item_id").val(id);
			if(lang == "en"){
			$('#pck_name').html(html.data.title.en);
			$('#pck_description').html(html.data.description.en);
			}else{
			$('#pck_name').html(html.data.title.ge);
			$('#pck_description').html(html.data.description.ge);
			}
			$('#pck_price').html('<i class="fa fa-euro"></i>'+html.data.price+'<span>/ '+html.data.expires_in_months+' Month</span>');
			
			$('#pck_crept').html('Credit Point :'+html.data.credit_point);
			$('#packageModalCenter').modal('show');
		}
	});		
});