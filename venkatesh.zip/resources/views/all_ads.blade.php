@extends('layout.default')

@section('content')
<section class="bannercontainer">
  <img src="{{ url('/')}}/images/banner-inner.jpg" alt="" />
  <div class="bannerinnercontent">
    @if($categoryDetails->resource->name)
    <h1>{{ $categoryDetails->resource->name}}</h1>
    @else
    <h1>All Ads</h1>
    @endif
  </div>
</section>


<section class="listingcontainer">
  <div class="container">
    <div class="row">
      <div class="col-xl-3 col-md-4 col-sm-12 col-12 filtermobilepanel">
        <div class="projectfilterbox">
          <div class="projectfilterbxinner">
            <div class="filterheading">
              <div class="filterhleft">
                filter by
              </div>
              <div class="filterhright">
                <a href="javascript:void(0);">Clear Filter</a>
              </div>
            </div>
            <div class="panel-group filterboxouter" id="" role="tablist" aria-multiselectable="true">
              <div class="panel panel-default filterbox">
                <div class="panel-heading filterbxheading">
                  <a class="ToggleIcon" role="button" data-toggle="collapse" data-parent="" href="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                    Categories
                  </a>
                </div>
                <div id="collapseOne" class="panel-collapse filterbxbody collapse in show" role="tabpanel" aria-expanded="true">
                  <div class="filterbxbodyinner pt-1 pb-0">
                    <div class="FilterInner">
                      @if(count($catList) > 0)
                        @foreach($catList as $list)
                        <a href="{{ url(app()->getLocale().'/all-ads')}}/{{$list->getPageslug->slug}}"><div class="checkbox">
                          <input type="checkbox" @if($cat_id == $list->id) checked @endif id="{{ $list->name }}" name="">
                          <label for="{{ $list->name }}">{{ $list->name }}<span>({{ count($list->getCategorywiseAds)}})</span></label>
                        </div></a>
                        @endforeach
                      @endif
                    </div>
                  </div>
                </div>
              </div>
              <div class="panel panel-default filterbox">
                <div class="panel-heading filterbxheading">
                  <a class="ToggleIcon" role="button" data-toggle="collapse" data-parent="" href="#collapseTwo" aria-expanded="true" aria-controls="collapseTwo">
                    Price
                  </a>
                </div>
                <div id="collapseTwo" class="panel-collapse filterbxbody collapse in show" role="tabpanel" aria-expanded="true">
                  <div class="filterbxbodyinner">
                    <input type="text" class="span2" value="" data-slider-min="0" data-slider-max="1500" data-slider-step="5" data-slider-value="[0,1000]" id="sl2">
                    <!-- <div class="pricerange">
                      <div class="rangevalue"><span class="first">$0</span><span class="sec">$2500.00</span></div>
                    </div> -->
                    <div class="pricerangebx">
                      <div class="input-group">
                        <select class="form-control">
                          <option selected="" hidden="">Min</option>
                          <option><i class="fa fa-euro"></i>100</option>
                          <option><i class="fa fa-euro"></i>150</option>
                          <option><i class="fa fa-euro"></i>200</option>
                          <option><i class="fa fa-euro"></i>250</option>
                        </select>
                        <div class="input-group-prepend">
                          <span class="input-group-text">to</span>
                        </div>
                        <select class="form-control">
                          <option selected="" hidden="">Max</option>
                          <option><i class="fa fa-euro"></i>500+</option>
                          <option><i class="fa fa-euro"></i>600+</option>
                          <option><i class="fa fa-euro"></i>700+</option>
                          <option><i class="fa fa-euro"></i>800+</option>
                        </select>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="panel panel-default filterbox">
                <div class="panel-heading filterbxheading">
                  <a class="ToggleIcon" role="button" data-toggle="collapse" data-parent="" href="#collapseThree" aria-expanded="true" aria-controls="collapseThree">
                    Location
                  </a>
                </div>
                <div id="collapseThree" class="filterbxbody collapse in show" role="tabpanel" aria-expanded="true">
                  <div class="filterbxbodyinner pt-1 pb-0">
                    <div class="searchbxfilter">
                      <input type="text" class="form-control" placeholder="Search State" name="">
                    </div>
                    <div class="FilterInner shopprice">
                      <ul>
                        <li><a href="javascript:void(0);">Berlin</a></li>
                        <li><a href="javascript:void(0);">Bayern (Bavaria)</a></li>
                        <li><a href="javascript:void(0);">Niedersachsen (Lower Saxony)</a></li>
                        <li><a href="javascript:void(0);">Baden-Württemberg</a></li>
                        <li><a href="javascript:void(0);">Rheinland-Pfalz (Rhineland-Palatinate)</a></li>
                        <li><a href="javascript:void(0);">Sachsen (Saxony)</a></li>
                        <li><a href="javascript:void(0);">Thüringen (Thuringia)</a></li>
                        <li><a href="javascript:void(0);">Hessen</a></li>
                        <li><a href="javascript:void(0);">Berlin</a></li>
                        <li><a href="javascript:void(0);">Bayern (Bavaria)</a></li>
                        <li><a href="javascript:void(0);">Niedersachsen (Lower Saxony)</a></li>
                        <li><a href="javascript:void(0);">Baden-Württemberg</a></li>
                        <li><a href="javascript:void(0);">Rheinland-Pfalz (Rhineland-Palatinate)</a></li>
                        <li><a href="javascript:void(0);">Sachsen (Saxony)</a></li>
                        <li><a href="javascript:void(0);">Thüringen (Thuringia)</a></li>
                        <li><a href="javascript:void(0);">Hessen</a></li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
              <div class="panel panel-default filterbox">
                <div class="panel-heading filterbxheading">
                  <a class="ToggleIcon" role="button" data-toggle="collapse" data-parent="" href="#collapseFour" aria-expanded="true" aria-controls="collapseFour">
                    Customer Ratings
                  </a>
                </div>
                <div id="collapseFour" class="filterbxbody collapse in show" role="tabpanel" aria-expanded="true">
                  <div class="filterbxbodyinner pt-1 pb-0">
                    <div class="FilterInner shopprice">
                      <div class="checkbox">
                        <input type="checkbox" id="4above" name="">
                        <label for="4above">4 <i class="fa fa-star"></i> & above</label>
                      </div>
                      <div class="checkbox">
                        <input type="checkbox" id="3above" name="">
                        <label for="3above">3 <i class="fa fa-star"></i> & above</label>
                      </div>
                      <div class="checkbox">
                        <input type="checkbox" id="2above" name="">
                        <label for="2above">2 <i class="fa fa-star"></i> & above</label>
                      </div>
                      <div class="checkbox">
                        <input type="checkbox" id="1above" name="">
                        <label for="1above">1 <i class="fa fa-star"></i> & above</label>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="col-xl-9 col-md-8 col-sm-12 col-12">
        <div class="prolistouter">
          <div class="listingbreadcrumb">
            <ol class="breadcrumb">
              <li><a href="{{ url('/')}}">Home</a></li>
              @if($categoryDetails->resource->name)
              <li class="active">{{ $categoryDetails->resource->name}}</li>
              @else
              <li class="active">All Ads</li>
              @endif
            </ol>
          </div>
          @if(count($allAdsList) > 0)
          <div class="topfilterpanel">            
            <div class="paginate">Showing  {{ $allAdsList->firstItem() }} – {{ $allAdsList->lastItem() }} Results of {{ $allAdsList->total() }} ( {{ $allAdsList->lastPage() }} pages)</div>
            <a class="FilterBtn categorieslink" href="javascript:void(0);"><i class="fa fa-filter"></i>Filter</a>
            <div class="filterboxright">
              <div class="sorttext">Sort By :</div>
              <div class="filterselect">
                <select class="form-control" onchange="location = this.value;">  
                  <option value="{{ url(app()->getLocale().'/all-ads')}}/{{$categoryDetails->slug}}?sort=title&order=ASC">Default</option>                
                  <option value="{{ url(app()->getLocale().'/all-ads')}}/{{$categoryDetails->slug}}?sort=title&order=DESC">Name (Z - A)</option>
                  <option value="{{ url(app()->getLocale().'/all-ads')}}/{{$categoryDetails->slug}}?sort=title&order=ASC">Name (A - Z)</option>                  
                  <option value="{{ url(app()->getLocale().'/all-ads')}}/{{$categoryDetails->slug}}?sort=amount&order=ASC">Price Low to High</option>
                  <option value="{{ url(app()->getLocale().'/all-ads')}}/{{$categoryDetails->slug}}?sort=amount&order=DESC">Price High to Low</option>                 
                </select>
              </div>
              <div class="tabbox">
                <a href="javascript:void(0);" id="grid-view"><i class="fa fa-th" aria-hidden="true"></i></a>
                <a class="active" href="javascript:void(0);" id="list-view"><i class="fa fa-list" aria-hidden="true"></i></a>
              </div>
            </div>
          </div>
          <div class="probxsec">
            <div class="row">
              @if($allAdsList)
                @foreach($allAdsList as $ads)
                <div class="product-list col-xl-12 col-md-12 col-sm-12 col-12 colproject">
                  <div class="projectlistbx">
                    <div class="prorow">
                      <div class="proimgleft">
                        <img src="{{ url('/')}}/{{  $ads->images }}" alt="" />
                      </div>
                      <div class="procontetleft">
                        <div class="procontentinner">
                          <div class="ptro">
                            <div class="ptroleft">
                              <h3><a href="{{ url(app()->getLocale().'/adsdetails')}}/{{$ads->getPageslug->slug}}">{{ $ads->title}}</a></h3>
                              <div class="loaction"><i class="fa fa-map-marker"></i>{{ $ads->getAdvtStates->state_name}}, {{ $ads->getAdvtCountry->country_name}}</div>
                              <p>{{ \Illuminate\Support\Str::limit($ads->short_description, 150, $end=' ') }} <a href="javascript:void(0);">[...]</a></p>
                              <!-- {!! html_entity_decode($ads->short_description) !!} -->
                            </div>
                            <div class="ptroright">
                              <div class="date"><i class="fa fa-calendar"></i>Posted: {{ date('d-m-Y',strtotime($ads->created_at)) }}</div>
                              <div class="pricebx">
                                <div class="pricebxinner">
                                  &euro;{{ $ads->amount }}
                                </div>
                              </div>
                              <div class="areabx">
                                <div class="rating">
                                  <i class="fa fa-star"></i>
                                  <i class="fa fa-star"></i>
                                  <i class="fa fa-star"></i>
                                  <i class="fa fa-star"></i>
                                  <i class="fa fa-star"></i>
                                </div>
                                <div class="areabxbtm">
                                  <span class="areatop">5000</span>
                                  <span class="areabottom">Area in sq ft</span>
                                </div>
                              </div>
                            </div>
                          </div>
                         
                          <div class="amentiesbox">
                            @php $i=1 @endphp
                            @if($ads->getAdvtamenities)
                              @foreach($ads->getAdvtamenities as $amenities)
                              <div class="amentiestx">
                                <div class="amentiestxinner">
                                  <i class="icon {{$amenities->getAmenties->image}}"></i>
                                  <span>
{{ \Illuminate\Support\Str::limit($amenities->getAmenties->name, 10, $end='..') }}
                                  </span>
                                </div>
                              </div>
                              @if($i == 4)
                              @php break @endphp
                              @endif

                              @php $i++ @endphp
                              @endforeach
                            @endif
                             @if($ads->getAdvtamenities)
                            <div class="amentiestx">
                              <div class="amentiestxinner">
                                <a id="AmentiesDrop" href="javascript:void(0);"><i class="fa fa-ellipsis-h" aria-hidden="true"></i></a>
                                <div id="AmentiesDropBox" class="amentiesnav">
                                  <ul>
                                      @foreach($ads->getAdvtamenities as $amenities)
                                    <li><a href="javascript:void(0);"><i class="icon {{$amenities->getAmenties->image}}"></i>{{$amenities->getAmenties->name}}</a></li>
                                    @endforeach
                                    
                                  </ul>
                                </div>
                              </div>
                            </div>
                            @endif
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                @endforeach
              @endif            
              
                <div class="col-12">
                  <div class="spinnerbx">
                    {{ $allAdsList->links() }}
                  </div>
                </div>
            </div>
          </div>
          @else
          <div class="probxsec">
            <div class="col-xl-12 col-md-12 col-sm-12 col-12 colproject">
              No data Found!
            </div>
          </div>
          @endif
        </div>
      </div>
    </div>
  </div>
</section>

@endsection