    @extends('layout.default')

    @section('content')

    <div class="dashboard">
	  <div class="dashboardcontainer">
	    <div class="afterloginnavigation">
	      <div class="usercolumn">
	        <div class="userimg">
	        @if($userDetails->photo)
	          <img src="{{ url('/')}}/{{ $userDetails->photo }}" alt="User Image">
	        @else
	          <img src="{{ url('/')}}/images/user-noimage.jpg" alt="User Image">
	        @endif
	        </div>
	        <h3>{{ $userDetails->name }}</h3>
	        <!-- <p>Visual artist</p> -->
	      </div>
	      <div class="usernavlist">
	         @include('layout.sidebar') 
	      </div>
	    </div>
	    <div class="layoutcontainer">
	      <div class="layoutcontent">
	        <div class="layoutcontentinner">
	          <div class="afterrightbox">
		          <a class="profilebtn" href="javascript:void(0);"><i class="icon icon-user"></i><span>Profile Nav</span></a>
		          <h3>Dashboard / Wallet</h3>
		          <div class="row">
		          	<div class="col-12">
		          		<div class="walletboxouter">
		          			<div class="walletheading">
		          				<div class="walleticon"><i class="icon icon-wallet"></i></div>
		          				<div class="walletcontent">
		          					<h4>Credit Point</h4>
		          					<p>{{ $userDetails->credit_point}}</p>
		          				</div>
		          				<div class="walletadbox">
		          					<a href="{{ url('/purchase-packages')}}" class="addmoneybtn"><i class="fa fa-plus"></i> <span>Add Credit Point to Wallet</span></a>
		          				</div>
		          			</div>
		          			<div class="walletbody">
		          				<div class="walletlist">
		          					<div class="walletlisticon">
		          						<i class="fa fa-plus"></i>
		          					</div>
		          					<div class="walletlistcontent">
		          						<h5>Money Transfer Joana</h5>
		          						<p>27/04/2020 - 14:40</p>
		          					</div>
		          					<div class="walletlistprice">
		          						<span class="green">120.00</span>
		          					</div>
		          				</div>
		          				<div class="walletlist">
		          					<div class="walletlisticon">
		          						<i class="fa fa-minus"></i>
		          					</div>
		          					<div class="walletlistcontent">
		          						<h5>Purchage Book</h5>
		          						<p>26/04/2020 - 16:01</p>
		          					</div>
		          					<div class="walletlistprice">
		          						<span class="red">50.00</span>
		          					</div>
		          				</div>
		          				<div class="walletlist">
		          					<div class="walletlisticon">
		          						<i class="fa fa-plus"></i>
		          					</div>
		          					<div class="walletlistcontent">
		          						<h5>Money Transfer Smith</h5>
		          						<p>26/04/2020 - 16:01</p>
		          					</div>
		          					<div class="walletlistprice">
		          						<span class="green">150.00</span>
		          					</div>
		          				</div>
		          				<div class="walletlist">
		          					<div class="walletlisticon">
		          						<i class="fa fa-minus"></i>
		          					</div>
		          					<div class="walletlistcontent">
		          						<h5>Purchage Shirt</h5>
		          						<p>26/04/2020 - 16:01</p>
		          					</div>
		          					<div class="walletlistprice">
		          						<span class="red">70.00</span>
		          					</div>
		          				</div>
		          				<div class="walletlist">
		          					<div class="walletlisticon">
		          						<i class="fa fa-plus"></i>
		          					</div>
		          					<div class="walletlistcontent">
		          						<h5>Money Transfer Joana</h5>
		          						<p>27/04/2020 - 14:40</p>
		          					</div>
		          					<div class="walletlistprice">
		          						<span class="green">120.00</span>
		          					</div>
		          				</div>
		          				<div class="walletlist">
		          					<div class="walletlisticon">
		          						<i class="fa fa-minus"></i>
		          					</div>
		          					<div class="walletlistcontent">
		          						<h5>Purchage Book</h5>
		          						<p>26/04/2020 - 16:01</p>
		          					</div>
		          					<div class="walletlistprice">
		          						<span class="red">50.00</span>
		          					</div>
		          				</div>
		          			</div>
		          		</div>
		          	</div>
		          </div>
		        </div>
	        </div>
	      </div>
	    </div>
	  </div>
	</div>


    @endsection