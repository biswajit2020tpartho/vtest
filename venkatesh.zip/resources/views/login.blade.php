@extends('layout.default')

@section('content')
<section class="logincontainer">
  <div class="logininner">
    <div class="container">
      <div class="row">
        <div class="col-xl-6 col-md-6 col-sm-12 col-12 pl-0 pr-0">
          <div class="lblright loginleft">
            <div class="lblrightinner">
              @if(Session::has('error_message'))
              <div class="alert {{ Session::get('alert-class', 'alert-danger alert-dismissible') }}">{{ Session::get('error_message') }}<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button></div>
              @endif 
              @if(Session::has('success_message'))
              <div class="alert {{ Session::get('alert-class', 'alert-success alert-dismissible') }}">{{ Session::get('success_message') }}<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button></div>
              @endif 
              <div class="innerbox">
                <div class="lgheading">Welcome Back!</div>
                <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
                <div class="lform">
                  <form method="post" id="login_form" action="{!! url('en/login-validate') !!}">
                @csrf
                  <div class="form-group">
                    <div class="formgroupinner">
                      <i class="fa fa-envelope-o"></i>
                      <input type="text" name="email_id_log" id="email_id_log" class="form-control" placeholder="Email" autocomplete="off">
                      @if($errors->has('email_id_log'))
                            <div class="error">{{ $errors->first('email_id_log') }}</div>
                      @endif    
                    </div>
                  </div>
                  <div class="form-group">
                    <div class="formgroupinner">
                      <i class="icon icon-password"></i>
                      <button class="p-view"><i class="icon icon-eye-slash"></i></button>
                      <input type="password" name="password_log" id="password_log" class="form-control" placeholder="Password" name="">
                      @if($errors->has('password_log'))
                            <div class="error">{{ $errors->first('password_log') }}</div>
                      @endif 
                    </div>
                  </div>
                  <div class="forgot">
                    <a href="javascript:void(0);" id="forgot_pwd">Forgot your password?</a>
                  </div>
                  <div class="checkbox">
                    <input type="checkbox" id="keepme" name="">
                    <label for="keepme">Keep me signed in</label>
                  </div>
                  <button class="lgbtn" type="submit">Login</button>
                   </form>
                   <form method="post" id="forgot_password_form" action="{!! url('en/forgot-password') !!}" style="display:none;">

            @csrf
            <div class="form-group">
              <input type="text" class="form-control" name="email_id_forgot" id="email_id_forgot" value="" placeholder="Email Id" autocomplete="off" />
              <small id="email_id_forgot_err" class="errmsg hidemsg"></small>
            </div>
           
            <a class="forgot" href="javascript:void(0);" id="sign_in">Sign In?</a>
            <button class="lgbtn" type="submit">Submit</button>
                   </form>
                  <div class="facebookwr">
                    <span>Login with</span><a class="facebook" href="javascript:void(0);"><i class="fa fa-facebook"></i></a>
                  </div>
                </div>
              </div>
           
            
            </div>
          </div>
        </div>
        <div class="col-xl-6 col-md-6 col-sm-12 col-12 pl-0 pr-0">
          <div class="lblright">
            <div class="lblrightinner">
              <div class="innerbox">
                <div class="lgheading">Create an Account</div>
                <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
                <div class="lform">
                  @if ($errors->any())
              <div class="alert alert-danger">
                <ul>
                  @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                  @endforeach
                </ul>
              </div>
              @endif
                  <form id="registration_form" action="{{ url('en/customer-insert')}}" method="post">
                 @csrf
                  <div class="row ml-n2 mr-n2">
                    <div class="col-xl-6 col-md-12 col-sm-12 col-12 pl-2 pr-2">
                      <div class="form-group">
                        <div class="formgroupinner">
                          <i class="icon icon-user"></i>
                          <input type="text" class="form-control" placeholder="User Name" name="user_name" id="user_name">
                        </div>  
                        <!-- @if($errors->has('user_name'))
                            <div class="error">{{ $errors->first('user_name') }}</div>
                        @endif     -->                  
                      </div>
                    </div>
                    <div class="col-xl-6 col-md-12 col-sm-12 col-12 pl-2 pr-2">
                      <div class="form-group">
                        <div class="formgroupinner">
                          <i class="icon icon-phone"></i>
                          <input type="text" class="form-control" placeholder="Phone Number" name="phone_number" id="phone_number">
                        </div>
                      </div>
                    </div>
                    <div class="col-xl-12 col-md-12 col-sm-12 col-12 pl-2 pr-2">
                      <div class="form-group">
                        <div class="formgroupinner">
                          <i class="fa fa-envelope-o"></i>
                          <input type="email" class="form-control" placeholder="Email" name="email" id="email">
                        </div>
                      </div>
                    </div>
                    <div class="col-xl-12 col-md-12 col-sm-12 col-12 pl-2 pr-2">
                      <div class="form-group">
                        <div class="formgroupinner">
                          <i class="icon icon-password"></i>
                          <button class="p-view"><i class="icon icon-eye-slash"></i></button>
                          <input type="password" class="form-control" placeholder="Password" name="user_password" id="user_password">
                        </div>
                      </div>
                    </div>
                    <div class="col-xl-12 col-md-12 col-sm-12 col-12 pl-2 pr-2">
                      <div class="form-group">
                        <div class="formgroupinner">
                          <i class="icon icon-edit"></i>
                          <textarea class="form-control" placeholder="Description" name="description" id="description"></textarea>
                        </div>
                      </div>
                    </div>
                    <div class="col-xl-12 col-md-12 col-sm-12 col-12 pl-2 pr-2">
                      <div class="checkbox">
                        <input type="checkbox" id="agree" name="agree">
                        <label>I agree <a href="{{ url('en/cms/terms-and-conditions')}}" target="_blank">Terms and Conditions</a></label>
                      </div>
                    </div>
                    <div class="col-xl-12 col-md-12 col-sm-12 col-12 pl-2 pr-2">
                      <button class="lgbtn signupbtn" type="submit">Sign Up</button>
                    </div>
                  </div>
                </form>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

@endsection