@php $slug = end(explode("/", $_SERVER['REQUEST_URI']));
@endphp
<ul class="sf-menu">
  <li @if($slug =="dashboard") class="active" @endif><a href="{{ url('/dashboard')}}"><i class="icon icon-dashboard"></i>@lang('dashboard.dashboard_txt')</a></li>
  <li @if($slug =="update-account") class="active" @endif><a href="{{ url('/update-account')}}"><i class="icon icon-user-pencil"></i>Update Account</a></li>
  <li @if($slug =="purchase-packages") class="active" @endif><a href="{{ url('/purchase-packages')}}" ><i class="icon icon-shopping-basket"></i>Purchase Package</a></li>
  <li @if($slug =="wallet") class="active" @endif><a href="{{ url('/wallet')}}"><i class="icon icon-wallet"></i>Wallet</a></li>
  <li>
    <a href="javascript:void(0);"><i class="icon icon-comment"></i>Send Message</a>
    <ul>
      <li><a href="javascript:void(0);">Site Administrator</a></li>
      <li><a href="javascript:void(0);">Other Members</a></li>
    </ul>
  </li>
  <li @if($slug =="post-add") class="active" @endif><a href="{{ url('/post-add')}}"><i class="icon icon-speaker"></i>Post a new Ad</a></li>
  <li><a href="javascript:void(0);"><i class="icon icon-digital-marketing"></i>View and Manage Ads</a></li>
  <li @if($slug =="view-inquiries") class="active" @endif><a href="{{ url('/view-inquiries')}}"><i class="icon icon-search"></i>View Inquiries</a></li>
  <li><a href="{{('logout')}}"><i class="icon icon-power-off"></i>Logout</a></li>
</ul>