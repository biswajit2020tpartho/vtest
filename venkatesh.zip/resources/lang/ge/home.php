<?php

return [
	'how_it_work'	  =>'Wie es funktioniert',
    'feature_ads_txt' => 'AUSGEWÄHLTE ANZEIGEN',
    'banner_txt_1'    => 'Ihr digitaler Guru zum Kaufen / Verkaufen',
    'banner_txt_2'    => 'Kaufen / Verkaufen Sie überall und jederzeit zu Ihrem eigenen Komfort',
    'login_txt'		  => 'Einloggen',
    'sell_txt'        => 'Verkaufen', 
    'feature_cat_txt' => 'BELIEBTE KATEGORIEN',  
    'ads_cat_txt'	  => 'Anzeigenkategorie',
    'loc_txt'		  => 'Ort',
    'key_txt'         => 'Stichwort',
    'price_txt'       => 'Preis',
    'search_txt'	  => 'Suche', 
    'feedback_txt'    => 'Bitte geben Sie Ihr Feedback',
    'sub_btn'         => 'einreichen',
    'nos_of_user'     => 'Anzahl der Nutzer',
    'nos_of_vis'      => 'Besucherzahl',
];
