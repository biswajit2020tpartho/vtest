<?php

return [
	'dashboard_txt'	  => 'Instrumententafel',
];
