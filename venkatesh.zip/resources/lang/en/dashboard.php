<?php

return [
	'dashboard_txt'	  => 'Dashboard',
];
