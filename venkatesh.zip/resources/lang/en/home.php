<?php

return [
	'how_it_work'	  => 'How it works',
    'feature_ads_txt' => 'FEATURED ADS',
    'banner_txt_1'    => 'Your digital guru for buy / sell',
    'banner_txt_2'    => 'Buy / Sell anywhere anytime, at your own comfort',
    'login_txt'		  => 'Login',
    'sell_txt'        => 'Sell',  
    'feature_cat_txt' => 'FEATURED CATEGORIES',
    'ads_cat_txt'	  => 'Ad category',
    'loc_txt'		  => 'Location',
    'key_txt'         => 'Keyword',
    'price_txt'       => 'Price',
    'search_txt'	  => 'search',
    'feedback_txt'    => 'Please Give your Feedback',
    'sub_btn'         => 'Submit',
    'nos_of_user'     => 'Number of Users',
    'nos_of_vis'      => 'Number of Visitors',
];
